"""Application configuration via environment variables."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "Linux_device_logs" / "extracted"
DB_PATH = Path(os.environ.get("DB_PATH", str(BASE_DIR / "data" / "logparser.db")))
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", str(BASE_DIR / "data" / "uploads")))
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8000"))

# Anomaly thresholds
TEMP_SPIKE_THRESHOLD_C = float(os.environ.get("TEMP_SPIKE_THRESHOLD_C", "45.0"))
DRAIN_SPIKE_MAH_PER_MIN = float(os.environ.get("DRAIN_SPIKE_MAH_PER_MIN", "50.0"))
WEAK_SIGNAL_THRESHOLD_PCT = int(os.environ.get("WEAK_SIGNAL_THRESHOLD_PCT", "20"))
ROAM_WINDOW_SEC = int(os.environ.get("ROAM_WINDOW_SEC", "60"))
ROAM_COUNT_THRESHOLD = int(os.environ.get("ROAM_COUNT_THRESHOLD", "3"))
BATTERY_DROP_THRESHOLD_PCT = int(os.environ.get("BATTERY_DROP_THRESHOLD_PCT", "5"))
BATTERY_DROP_WINDOW_MIN = int(os.environ.get("BATTERY_DROP_WINDOW_MIN", "5"))
TEMP_COLD_THRESHOLD_C = float(os.environ.get("TEMP_COLD_THRESHOLD_C", "0.0"))
BATTERY_SWAP_JUMP_PCT = int(os.environ.get("BATTERY_SWAP_JUMP_PCT", "30"))
DATA_GAP_THRESHOLD_SEC = int(os.environ.get("DATA_GAP_THRESHOLD_SEC", "300"))
RSSI_LOW_BURST_COUNT = int(os.environ.get("RSSI_LOW_BURST_COUNT", "10"))
RSSI_LOW_BURST_WINDOW_SEC = int(os.environ.get("RSSI_LOW_BURST_WINDOW_SEC", "120"))
BATTERY_CRITICAL_PCT = int(os.environ.get("BATTERY_CRITICAL_PCT", "15"))

# System resource thresholds
CPU_HIGH_THRESHOLD_PCT = float(os.environ.get("CPU_HIGH_THRESHOLD_PCT", "80.0"))
RAM_HIGH_THRESHOLD_PCT = int(os.environ.get("RAM_HIGH_THRESHOLD_PCT", "80"))
FLASH_HIGH_THRESHOLD_PCT = int(os.environ.get("FLASH_HIGH_THRESHOLD_PCT", "90"))

# Voice quality thresholds
SAY_AGAIN_RATE_THRESHOLD_PCT = float(os.environ.get("SAY_AGAIN_RATE_THRESHOLD_PCT", "10.0"))

# Headset disconnect burst detection
HEADSET_DISCONNECT_BURST_COUNT = int(os.environ.get("HEADSET_DISCONNECT_BURST_COUNT", "3"))
HEADSET_DISCONNECT_BURST_WINDOW_SEC = int(os.environ.get("HEADSET_DISCONNECT_BURST_WINDOW_SEC", "300"))
