"""SQLite persistence layer.

Stores parsed sessions, events, and anomalies with query-friendly indices.
Uses WAL mode for safe concurrent reads during web serving.
"""

from __future__ import annotations

import dataclasses as dc
import json
import sqlite3
from pathlib import Path
from typing import Optional

from app import config
from app.anomaly import AnomalyRecord
from app.parser import LogEvent, SessionMeta


def get_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Open a connection with WAL mode and useful pragmas."""
    path = db_path or config.DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _shift_bucket_sql(column: str) -> str:
    """Return a SQL CASE expression that maps HH:MM timestamps to shift buckets."""
    return f"""
        CASE
            WHEN {column} IS NULL OR TRIM({column}) = '' OR LENGTH({column}) < 2 THEN 'Unknown'
            WHEN CAST(SUBSTR({column}, 1, 2) AS INTEGER) BETWEEN 6 AND 13 THEN 'Morning Shift'
            WHEN CAST(SUBSTR({column}, 1, 2) AS INTEGER) BETWEEN 14 AND 21 THEN 'Afternoon Shift'
            WHEN CAST(SUBSTR({column}, 1, 2) AS INTEGER) BETWEEN 0 AND 23 THEN 'Night Shift'
            ELSE 'Unknown'
        END
    """


def init_db(conn: sqlite3.Connection) -> None:
    """Create tables and indices if they don't exist."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_file TEXT NOT NULL,
            terminal_name TEXT,
            terminal_serial TEXT,
            firmware_version TEXT,
            ip_address TEXT,
            log_start_time TEXT,
            log_stop_time TEXT,
            log_type TEXT,
            total_events INTEGER DEFAULT 0,
            total_anomalies INTEGER DEFAULT 0,
            health_score INTEGER DEFAULT 100,
            summary_json TEXT DEFAULT '{}',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL REFERENCES sessions(id),
            source_file TEXT,
            terminal_name TEXT,
            line_start INTEGER,
            line_end INTEGER,
            server_timestamp TEXT,
            device_time TEXT,
            device_tick INTEGER,
            component TEXT,
            event_type TEXT,
            severity TEXT,
            message TEXT,
            raw_lines TEXT,
            battery_json TEXT,
            wifi_json TEXT,
            tags TEXT,
            anomalies TEXT,
            is_multiline BOOLEAN DEFAULT 0,
            uncertain BOOLEAN DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id);
        CREATE INDEX IF NOT EXISTS idx_events_session_line ON events(session_id, line_start);
        CREATE INDEX IF NOT EXISTS idx_events_session_component_line ON events(session_id, component, line_start);
        CREATE INDEX IF NOT EXISTS idx_events_session_type_line ON events(session_id, event_type, line_start);
        CREATE INDEX IF NOT EXISTS idx_events_component ON events(component);
        CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
        CREATE INDEX IF NOT EXISTS idx_events_device_time ON events(device_time);
        CREATE INDEX IF NOT EXISTS idx_events_anomalies ON events(anomalies);

        CREATE TABLE IF NOT EXISTS anomalies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL REFERENCES sessions(id),
            anomaly_type TEXT NOT NULL,
            severity TEXT,
            description TEXT,
            device_time TEXT,
            line_start INTEGER,
            line_end INTEGER,
            source_file TEXT,
            value REAL,
            threshold REAL
        );

        CREATE INDEX IF NOT EXISTS idx_anomalies_session ON anomalies(session_id);
        CREATE INDEX IF NOT EXISTS idx_anomalies_session_line ON anomalies(session_id, line_start);
        CREATE INDEX IF NOT EXISTS idx_anomalies_type ON anomalies(anomaly_type);
    """)
    conn.commit()


def insert_session(conn: sqlite3.Connection, meta: SessionMeta) -> int:
    """Insert a session record and return its id."""
    cur = conn.execute(
        """INSERT INTO sessions
           (source_file, terminal_name, terminal_serial, firmware_version,
            ip_address, log_start_time, log_stop_time, log_type)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            meta.source_file, meta.terminal_name, meta.terminal_serial,
            meta.firmware_version, meta.ip_address,
            meta.log_start_time, meta.log_stop_time, meta.log_type,
        ),
    )
    conn.commit()
    return cur.lastrowid  # type: ignore[return-value]


def insert_events_batch(
    conn: sqlite3.Connection, session_id: int, events: list[LogEvent]
) -> None:
    """Bulk insert events for a session."""
    rows = []
    for ev in events:
        battery_json = json.dumps(dc.asdict(ev.battery)) if ev.battery else None
        wifi_json = json.dumps(dc.asdict(ev.wifi)) if ev.wifi else None
        rows.append((
            session_id, ev.source_file, ev.terminal_name,
            ev.line_start, ev.line_end, ev.server_timestamp,
            ev.device_time, ev.device_tick, ev.component,
            ev.event_type, ev.severity, ev.message, ev.raw_lines,
            battery_json, wifi_json, ev.tags, ev.anomalies,
            ev.is_multiline, ev.uncertain,
        ))
    conn.executemany(
        """INSERT INTO events
           (session_id, source_file, terminal_name, line_start, line_end,
            server_timestamp, device_time, device_tick, component, event_type,
            severity, message, raw_lines, battery_json, wifi_json, tags,
            anomalies, is_multiline, uncertain)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.commit()


def insert_anomalies_batch(
    conn: sqlite3.Connection, session_id: int, records: list[AnomalyRecord]
) -> None:
    """Bulk insert anomaly records for a session."""
    rows = [
        (session_id, r.anomaly_type, r.severity, r.description,
         r.device_time, r.line_start, r.line_end, r.source_file,
         r.value, r.threshold)
        for r in records
    ]
    conn.executemany(
        """INSERT INTO anomalies
           (session_id, anomaly_type, severity, description, device_time,
            line_start, line_end, source_file, value, threshold)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.commit()


def update_session_summary(
    conn: sqlite3.Connection, session_id: int,
    total_events: int, total_anomalies: int,
    health_score: int, summary: dict,
) -> None:
    """Update session with post-parse summary stats.

    The persisted `health_score` column is retained only for backward
    compatibility with existing SQLite databases.
    """
    conn.execute(
        """UPDATE sessions SET total_events=?, total_anomalies=?,
           health_score=?, summary_json=? WHERE id=?""",
        (total_events, total_anomalies, health_score,
         json.dumps(summary), session_id),
    )
    conn.commit()


def update_session_summary_json(
    conn: sqlite3.Connection, session_id: int, summary: dict,
) -> None:
    """Persist only the session summary JSON payload."""
    conn.execute(
        "UPDATE sessions SET summary_json=? WHERE id=?",
        (json.dumps(summary), session_id),
    )
    conn.commit()


# ── Query helpers ───────────────────────────────────────────────────────────

def get_sessions(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM sessions ORDER BY created_at DESC"
    ).fetchall()
    return [dict(r) for r in rows]


def session_exists_for_file(
    conn: sqlite3.Connection, source_file: str, terminal_serial: str,
) -> bool:
    """Check if a session has already been ingested for this file + device."""
    row = conn.execute(
        "SELECT 1 FROM sessions WHERE source_file=? AND terminal_serial=? LIMIT 1",
        (source_file, terminal_serial),
    ).fetchone()
    return row is not None


def get_session(conn: sqlite3.Connection, session_id: int) -> Optional[dict]:
    row = conn.execute(
        "SELECT * FROM sessions WHERE id=?", (session_id,)
    ).fetchone()
    return dict(row) if row else None


def delete_session(conn: sqlite3.Connection, session_id: int) -> None:
    """Delete a session and all dependent records."""
    conn.execute("DELETE FROM anomalies WHERE session_id=?", (session_id,))
    conn.execute("DELETE FROM events WHERE session_id=?", (session_id,))
    conn.execute("DELETE FROM sessions WHERE id=?", (session_id,))
    conn.commit()


def get_events(
    conn: sqlite3.Connection, session_id: int,
    component: Optional[str] = None,
    event_type: Optional[str] = None,
    query_text: Optional[str] = None,
    has_anomaly: bool = False,
    limit: int = 500, offset: int = 0,
) -> list[dict]:
    query = "SELECT * FROM events WHERE session_id=?"
    params: list = [session_id]
    if component:
        query += " AND component=?"
        params.append(component)
    if event_type:
        query += " AND event_type=?"
        params.append(event_type)
    if query_text:
        query += " AND (message LIKE ? OR component LIKE ? OR event_type LIKE ?)"
        like_value = f"%{query_text}%"
        params.extend([like_value, like_value, like_value])
    if has_anomaly:
        query += " AND anomalies != ''"
    query += " ORDER BY line_start LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def iter_events(conn: sqlite3.Connection, session_id: int):
    """Iterate over all events for a session without loading them all into memory."""
    cur = conn.execute(
        "SELECT * FROM events WHERE session_id=? ORDER BY line_start",
        (session_id,),
    )
    while True:
        row = cur.fetchone()
        if row is None:
            break
        yield dict(row)


def get_event_count(
    conn: sqlite3.Connection, session_id: int,
    component: Optional[str] = None,
    event_type: Optional[str] = None,
    query_text: Optional[str] = None,
    has_anomaly: bool = False,
) -> int:
    query = "SELECT COUNT(*) as cnt FROM events WHERE session_id=?"
    params: list = [session_id]
    if component:
        query += " AND component=?"
        params.append(component)
    if event_type:
        query += " AND event_type=?"
        params.append(event_type)
    if query_text:
        query += " AND (message LIKE ? OR component LIKE ? OR event_type LIKE ?)"
        like_value = f"%{query_text}%"
        params.extend([like_value, like_value, like_value])
    if has_anomaly:
        query += " AND anomalies != ''"
    row = conn.execute(query, params).fetchone()
    return row["cnt"] if row else 0


def get_events_around_line(
    conn: sqlite3.Connection,
    session_id: int,
    around_line: int,
    context_lines: int = 25,
) -> list[dict]:
    """Return events overlapping a line-centered window for exact evidence jumps."""
    start_line = max(1, around_line - context_lines)
    end_line = around_line + context_lines
    rows = conn.execute(
        """SELECT * FROM events
           WHERE session_id=?
             AND line_end >= ?
             AND line_start <= ?
           ORDER BY line_start""",
        (session_id, start_line, end_line),
    ).fetchall()
    return [dict(r) for r in rows]


def get_anomalies(
    conn: sqlite3.Connection, session_id: int,
    anomaly_type: Optional[str] = None,
    query_text: Optional[str] = None,
) -> list[dict]:
    query = "SELECT * FROM anomalies WHERE session_id=?"
    params: list = [session_id]
    if anomaly_type:
        query += " AND anomaly_type=?"
        params.append(anomaly_type)
    if query_text:
        query += " AND (anomaly_type LIKE ? OR description LIKE ? OR severity LIKE ?)"
        like_value = f"%{query_text}%"
        params.extend([like_value, like_value, like_value])
    query += " ORDER BY line_start"
    rows = conn.execute(query, params).fetchall()
    return [dict(r) for r in rows]


def get_battery_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get battery events in chronological order for charting."""
    rows = conn.execute(
        """SELECT device_time, battery_json, line_start
           FROM events WHERE session_id=? AND battery_json IS NOT NULL
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    result = []
    for r in rows:
        data = json.loads(r["battery_json"])
        data["device_time"] = r["device_time"]
        data["line"] = r["line_start"]
        result.append(data)
    return result


def get_wifi_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get wifi events in chronological order for charting."""
    rows = conn.execute(
        """SELECT device_time, wifi_json, event_type, line_start
           FROM events WHERE session_id=? AND wifi_json IS NOT NULL
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    result = []
    for r in rows:
        data = json.loads(r["wifi_json"])
        data["device_time"] = r["device_time"]
        data["event_type"] = r["event_type"]
        data["line"] = r["line_start"]
        result.append(data)
    return result


def get_component_counts(conn: sqlite3.Connection, session_id: int) -> dict:
    rows = conn.execute(
        """SELECT component, COUNT(*) as cnt FROM events
           WHERE session_id=? GROUP BY component ORDER BY cnt DESC""",
        (session_id,),
    ).fetchall()
    return {r["component"]: r["cnt"] for r in rows}


def get_anomaly_type_counts(conn: sqlite3.Connection, session_id: int) -> dict:
    rows = conn.execute(
        """SELECT anomaly_type, COUNT(*) as cnt FROM anomalies
           WHERE session_id=? GROUP BY anomaly_type ORDER BY cnt DESC""",
        (session_id,),
    ).fetchall()
    return {r["anomaly_type"]: r["cnt"] for r in rows}


def get_shift_event_component_counts(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    shift_sql = _shift_bucket_sql("device_time")
    rows = conn.execute(
        f"""SELECT {shift_sql} AS shift_name,
                   COALESCE(component, 'other') AS component,
                   COUNT(*) AS cnt
            FROM events
            WHERE session_id=?
            GROUP BY shift_name, COALESCE(component, 'other')
            ORDER BY shift_name, cnt DESC""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_shift_anomaly_type_counts(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    shift_sql = _shift_bucket_sql("device_time")
    rows = conn.execute(
        f"""SELECT {shift_sql} AS shift_name,
                   COALESCE(anomaly_type, 'unknown') AS anomaly_type,
                   COUNT(*) AS cnt
            FROM anomalies
            WHERE session_id=?
            GROUP BY shift_name, COALESCE(anomaly_type, 'unknown')
            ORDER BY shift_name, cnt DESC""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_system_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get CPU/RAM/Flash resource events for charting."""
    rows = conn.execute(
        """SELECT device_time, event_type, message, line_start
           FROM events WHERE session_id=? AND event_type IN ('cpu_usage', 'ram_usage', 'flash_usage')
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_voice_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get voice recognized word events for charting."""
    rows = conn.execute(
        """SELECT device_time, message, line_start
           FROM events WHERE session_id=? AND event_type='voice_recognized_word'
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_operator_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get operator login events in chronological order."""
    rows = conn.execute(
        """SELECT device_time, message, line_start
           FROM events WHERE session_id=? AND event_type='operator_login'
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_headset_timeline(conn: sqlite3.Connection, session_id: int) -> list[dict]:
    """Get headset events in chronological order."""
    rows = conn.execute(
        """SELECT device_time, event_type, message, line_start
           FROM events WHERE session_id=? AND event_type IN ('headset_connected', 'headset_disconnected')
           ORDER BY line_start""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]
