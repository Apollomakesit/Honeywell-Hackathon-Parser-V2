"""Streaming log file parser.

Reads log files line-by-line, reconstructs multiline events, and yields
normalised LogEvent objects without loading the entire file into memory.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Generator, TextIO

from app.parser import LogEvent, SessionMeta

# ── Regex patterns ──────────────────────────────────────────────────────────

# Timestamp prefix: (M/DD/YY H:MM:SS AM/PM TZ) HH:MM:SS.mmm - tick: msg
_TS_PREFIX = re.compile(
    r"^\((\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2}:\d{2}\s+[AP]M\s+\w+)\)\s+"
    r"(\d{2}:\d{2}:\d{2}\.\d{3})\s+-\s+(\d+):\s*(.*)"
)

# Lines that start with a timestamp but have NO device-time (e.g. WARNING lines)
_TS_NODEVICE = re.compile(
    r"^\((\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2}:\d{2}\s+[AP]M\s+\w+)\)\s+(.*)"
)

# Header fields
_HEADER_PATTERNS = {
    "log_start_time": re.compile(r"^Log Start Time:\s*(.+)$"),
    "log_stop_time": re.compile(r"^Log Stop Time:\s*(.+)$"),
    "log_type": re.compile(r"^Log Type:\s*(.+)$"),
    "terminal_name": re.compile(r"^Terminal Name:\s*(.+)$"),
    "terminal_serial": re.compile(r"^Terminal Serial Number:\s*(.+)$"),
    "firmware_version": re.compile(r"^Firmware Version:\s*(.+)$"),
    "ip_address": re.compile(r"^IP Address:\s*(.+)$"),
}

_SEPARATOR = re.compile(r"^-{10,}$")


def parse_header(fh: TextIO, source_file: str) -> tuple[SessionMeta, int]:
    """Parse the header block at the top of a log file.

    Returns (SessionMeta, line_number_after_header).
    """
    meta = SessionMeta(source_file=source_file)
    lineno = 0
    for raw_line in fh:
        lineno += 1
        line = raw_line.rstrip("\n\r")
        if _SEPARATOR.match(line.strip()):
            break
        for field, pat in _HEADER_PATTERNS.items():
            m = pat.match(line.strip())
            if m:
                setattr(meta, field, m.group(1).strip())
                break
    return meta, lineno


def _split_wrapped_lines(raw_line: str) -> list[str]:
    """Some log lines are wrapped with embedded timestamps on the same line.

    e.g. 'message1                    (2/28/24 ...) 14:14:42.070 ...'
    Split those into separate logical lines.
    """
    # Find positions where a new timestamp starts within the line
    parts: list[str] = []
    splits = list(re.finditer(r"(?<=\S)\s{2,}\((\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2}:\d{2}\s+[AP]M\s+\w+)\)", raw_line))
    if not splits:
        return [raw_line]

    prev = 0
    for m in splits:
        part = raw_line[prev:m.start()].rstrip()
        if part:
            parts.append(part)
        prev = m.start()
        # Strip leading whitespace before the '('
        remaining = raw_line[prev:].lstrip()
        if remaining:
            parts.append(remaining)
            prev = len(raw_line)
            break
    # If there's leftover after the last split
    if prev < len(raw_line):
        tail = raw_line[prev:].lstrip()
        if tail:
            parts.append(tail)

    # Recurse on parts that may still have embedded timestamps
    result: list[str] = []
    for p in parts:
        if len(result) == 0:
            result.append(p)
        else:
            result.append(p)
    return result if result else [raw_line]


def _improved_split(raw_line: str) -> list[str]:
    """Split a raw line at every embedded timestamp boundary."""
    pattern = re.compile(
        r"(?<=[^\(])\s{2,}(?=\(\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2}:\d{2}\s+[AP]M\s+\w+\))"
    )
    parts = pattern.split(raw_line)
    return [p.strip() for p in parts if p.strip()]


def stream_events(
    fh: TextIO,
    meta: SessionMeta,
    start_lineno: int = 0,
) -> Generator[LogEvent, None, None]:
    """Yield LogEvent objects from an open file handle.

    The file handle should already be positioned after the header.
    """
    current_event: LogEvent | None = None
    uncertain = False  # tracks if we're after a messages-lost gap

    def _finalize(ev: LogEvent) -> LogEvent:
        ev.uncertain = uncertain
        return ev

    lineno = start_lineno

    for raw_line in fh:
        lineno += 1
        # Split wrapped lines that contain multiple timestamps on one line
        logical_lines = _improved_split(raw_line.rstrip("\n\r"))

        for lline in logical_lines:
            line = lline.strip()
            if not line:
                continue

            # Try full timestamp match
            m = _TS_PREFIX.match(line)
            if m:
                # New event boundary
                if current_event is not None:
                    yield _finalize(current_event)

                server_ts = m.group(1)
                device_time = m.group(2)
                device_tick = int(m.group(3))
                message = m.group(4)

                current_event = LogEvent(
                    source_file=meta.source_file,
                    terminal_name=meta.terminal_name,
                    line_start=lineno,
                    line_end=lineno,
                    server_timestamp=server_ts,
                    device_time=device_time,
                    device_tick=device_tick,
                    message=message,
                    raw_lines=line,
                )
                continue

            # Check for timestamp-only lines (no device time) like WARNING
            m_nd = _TS_NODEVICE.match(line)
            if m_nd:
                if current_event is not None:
                    yield _finalize(current_event)

                server_ts = m_nd.group(1)
                message = m_nd.group(2).strip()

                # Detect message-loss markers
                if "WARNING" in message and "Messages lost" in message:
                    uncertain = True
                    current_event = LogEvent(
                        source_file=meta.source_file,
                        terminal_name=meta.terminal_name,
                        line_start=lineno,
                        line_end=lineno,
                        server_timestamp=server_ts,
                        message=message,
                        component="system",
                        event_type="messages_lost",
                        severity="warning",
                        raw_lines=line,
                    )
                else:
                    current_event = LogEvent(
                        source_file=meta.source_file,
                        terminal_name=meta.terminal_name,
                        line_start=lineno,
                        line_end=lineno,
                        server_timestamp=server_ts,
                        message=message,
                        raw_lines=line,
                    )
                continue

            # Continuation line for multiline events
            if current_event is not None:
                current_event.message += "\n" + line
                current_event.raw_lines += "\n" + line
                current_event.line_end = lineno
                current_event.is_multiline = True
            # Else orphan line, skip

    # Final event
    if current_event is not None:
        yield _finalize(current_event)


def parse_file(path: str | Path) -> Generator[LogEvent, None, None]:
    """Top-level convenience: parse an entire log file, yielding events."""
    path = Path(path)
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        meta, header_end = parse_header(fh, source_file=str(path.name))
        yield from stream_events(fh, meta, start_lineno=header_end)


def parse_file_with_meta(path: str | Path) -> tuple[SessionMeta, Generator[LogEvent, None, None]]:
    """Parse a file, returning both session metadata and an event generator."""
    path = Path(path)
    fh = open(path, "r", encoding="utf-8", errors="replace")
    meta, header_end = parse_header(fh, source_file=str(path.name))
    return meta, stream_events(fh, meta, start_lineno=header_end)
