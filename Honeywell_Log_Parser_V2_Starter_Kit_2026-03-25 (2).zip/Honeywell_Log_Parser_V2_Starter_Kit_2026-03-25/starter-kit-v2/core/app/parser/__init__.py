"""Normalized event schema for parsed log entries."""

from __future__ import annotations

import dataclasses as dc
from typing import Optional


@dc.dataclass
class SessionMeta:
    """Metadata extracted from the log file header."""
    source_file: str = ""
    log_start_time: str = ""
    log_stop_time: str = ""
    log_type: str = ""
    terminal_name: str = ""
    terminal_serial: str = ""
    firmware_version: str = ""
    ip_address: str = ""


@dc.dataclass
class BatteryMetrics:
    """Extracted battery telemetry."""
    runtime_min: Optional[float] = None
    percent: Optional[float] = None
    temperature_c: Optional[float] = None
    energy_consumption_mah: Optional[float] = None
    voltage_mv: Optional[float] = None
    current_ma: Optional[float] = None


@dc.dataclass
class WifiMetrics:
    """Extracted Wi-Fi telemetry."""
    signal_strength_pct: Optional[int] = None
    signal_samples: Optional[str] = None
    access_point: Optional[str] = None
    bssid: Optional[str] = None
    rssi_event: Optional[str] = None  # RSSI_LOW / RSSI_HIGH
    roamed_from: Optional[str] = None
    roamed_to: Optional[str] = None
    connection_state: Optional[str] = None
    scan_event: Optional[str] = None  # sched_scan_start / sched_scan result


@dc.dataclass
class LogEvent:
    """A single normalized log event."""
    # Identity
    source_file: str = ""
    terminal_name: str = ""
    line_start: int = 0
    line_end: int = 0

    # Timestamps
    server_timestamp: str = ""
    device_time: str = ""
    device_tick: Optional[int] = None

    # Classification
    component: str = "unknown"
    event_type: str = "generic"
    severity: str = "info"

    # Content
    message: str = ""
    raw_lines: str = ""

    # Extracted metrics
    battery: Optional[BatteryMetrics] = None
    wifi: Optional[WifiMetrics] = None

    # Metadata
    tags: str = ""          # comma-separated
    anomalies: str = ""     # comma-separated anomaly codes
    is_multiline: bool = False
    uncertain: bool = False  # True when after a messages-lost gap
