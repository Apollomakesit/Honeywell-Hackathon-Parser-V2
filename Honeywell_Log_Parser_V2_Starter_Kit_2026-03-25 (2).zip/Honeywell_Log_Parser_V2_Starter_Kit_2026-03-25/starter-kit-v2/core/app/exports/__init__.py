"""Export and report generation: CSV, JSON, and HTML summary."""

from __future__ import annotations

import csv
import io
import json
from typing import Any


def events_to_csv(events: list[dict]) -> str:
    """Convert event dicts to a CSV string."""
    if not events:
        return ""
    output = io.StringIO()
    fields = [
        "line_start", "line_end", "device_time", "server_timestamp",
        "component", "event_type", "severity", "message", "anomalies",
        "battery_json", "wifi_json",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for ev in events:
        writer.writerow(ev)
    return output.getvalue()


def events_to_json(events: list[dict]) -> str:
    """Convert event dicts to a JSON string."""
    return json.dumps(events, indent=2, default=str)


def anomalies_to_csv(anomalies: list[dict]) -> str:
    if not anomalies:
        return ""
    output = io.StringIO()
    fields = [
        "anomaly_type", "severity", "description", "device_time",
        "line_start", "line_end", "value", "threshold",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for a in anomalies:
        writer.writerow(a)
    return output.getvalue()


def incidents_to_csv(incidents: list[dict]) -> str:
    """Convert grouped incident dicts to a CSV string."""
    if not incidents:
        return ""
    output = io.StringIO()
    fields = [
        "label", "anomaly_type", "severity", "confidence", "confidence_reason",
        "count", "start_time", "end_time", "start_line", "end_line",
      "summary",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for incident in incidents:
        writer.writerow(incident)
    return output.getvalue()


def generate_html_report(
    session: dict,
    summary: dict,
    anomalies: list[dict],
    battery_timeline: list[dict],
    wifi_timeline: list[dict],
) -> str:
    """Generate a self-contained HTML summary report."""
    s = summary
    bat = s.get("battery", {})
    wifi = s.get("wifi", {})

    anomaly_rows = ""
    for a in anomalies[:100]:  # Limit for report size
        sev_class = "critical" if a.get("severity") == "critical" else "warning"
        anomaly_rows += f"""
        <tr class="{sev_class}">
            <td>{_esc(a.get('anomaly_type', ''))}</td>
            <td>{_esc(a.get('severity', ''))}</td>
            <td>{_esc(a.get('description', ''))}</td>
            <td>{_esc(a.get('device_time', ''))}</td>
            <td>{a.get('line_start', '')}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Device Analysis Report — {_esc(session.get('terminal_name', 'Unknown'))}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<style>
:root {{ --bg: #0d0f12; --card: #181b21; --text: #f0f0f2; --accent: #D81E05; --warn: #fbbf24; --crit: #ef4444; --ok: #22c55e; --muted: #8b8f97; --border: #2a2d35; }}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: 'Inter', system-ui, sans-serif; background: var(--bg); color: var(--text); padding: 2rem; }}
h1 {{ color: #fff; margin-bottom: .5rem; font-size: 1.8rem; }}
h1 .accent {{ color: var(--accent); }}
h2 {{ color: #fff; margin: 1.5rem 0 .75rem; font-size: 1.2rem; }}
.meta {{ color: var(--muted); margin-bottom: 2rem; }}
.cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }}
.card {{ background: var(--card); padding: 1.25rem; border-radius: .75rem; border: 1px solid var(--border); }}
.card .label {{ font-size: .75rem; color: var(--muted); text-transform: uppercase; letter-spacing: .05em; }}
.card .value {{ font-size: 1.8rem; font-weight: 700; margin-top: .25rem; color: #fff; }}
.card .value.ok {{ color: var(--ok); }}
.card .value.warn {{ color: var(--warn); }}
.card .value.crit {{ color: var(--crit); }}
.card .hint {{ font-size: .72rem; color: var(--muted); margin-top: .2rem; }}
table {{ width: 100%; border-collapse: collapse; margin: 1rem 0; }}
th, td {{ padding: .5rem .75rem; text-align: left; border-bottom: 1px solid var(--border); font-size: .85rem; }}
th {{ color: var(--muted); text-transform: uppercase; font-size: .7rem; letter-spacing: .05em; }}
tr.critical td {{ color: var(--crit); }}
tr.warning td {{ color: var(--warn); }}
.chart-box {{ background: var(--card); border-radius: .75rem; padding: 1rem; margin: 1rem 0; border: 1px solid var(--border); }}
canvas {{ max-height: 300px; }}
.footer {{ text-align: center; padding: 2rem; color: var(--muted); font-size: .8rem; margin-top: 2rem; border-top: 1px solid var(--border); }}
.brand {{ color: var(--accent); font-weight: 600; }}
</style>
</head>
<body>
<h1><span class="accent">Honeywell</span> Device Analysis Report</h1>
<p class="meta">
Device: <strong>{_esc(session.get('terminal_name', ''))}</strong> |
Firmware: {_esc(session.get('firmware_version', ''))} |
Period: {_esc(session.get('log_start_time', ''))} → {_esc(session.get('log_stop_time', ''))}
</p>

<div class="cards">
    <div class="card"><div class="label">Stored Flags</div>
      <div class="value warn">{s.get('total_anomalies', 0)}</div>
      <div class="hint">Stored flag rows produced by parsed triggers</div></div>
  <div class="card"><div class="label">Events Analyzed</div>
    <div class="value">{session.get('total_events', 0):,}</div>
    <div class="hint">Log entries processed</div></div>
    <div class="card"><div class="label">Observed Wi-Fi Roams</div>
      <div class="value">{wifi.get('total_roams', 0)}</div>
      <div class="hint">Parsed Wi-Fi roaming events</div></div>
  <div class="card"><div class="label">Lost Messages</div>
    <div class="value warn">{s.get('message_loss_count', 0)}</div>
    <div class="hint">Gaps in recording</div></div>
</div>

<div class="cards">
  <div class="card"><div class="label">Battery Change</div>
    <div class="value">{bat.get('total_drain', 'N/A')}%</div>
    <div class="hint">Net charge lost or gained</div></div>
  <div class="card"><div class="label">Temperature Range</div>
    <div class="value">{bat.get('temp_min', '?')}–{bat.get('temp_max', '?')}°C</div>
    <div class="hint">Min – Max battery temp</div></div>
  <div class="card"><div class="label">Wi-Fi Coverage Range</div>
    <div class="value">{wifi.get('signal_min', '?')}–{wifi.get('signal_max', '?')}%</div>
    <div class="hint">Min – Max Wi-Fi coverage</div></div>
  <div class="card"><div class="label">AP Switches</div>
    <div class="value">{wifi.get('total_roams', 0)}</div>
    <div class="hint">Roaming events</div></div>
</div>

<h2>Battery Over Time</h2>
<div class="chart-box"><canvas id="batteryChart"></canvas></div>

<h2>Wi-Fi Signal Over Time</h2>
<div class="chart-box"><canvas id="wifiChart"></canvas></div>

<h2>Issues Detected (top 100)</h2>
<table>
<thead><tr><th>Type</th><th>Severity</th><th>Description</th><th>Time</th><th>Line</th></tr></thead>
<tbody>{anomaly_rows}</tbody>
</table>

<script>
const batteryData = {json.dumps(_battery_chart_data(battery_timeline))};
const wifiData = {json.dumps(_wifi_chart_data(wifi_timeline))};

if (batteryData.labels.length) {{
  new Chart(document.getElementById('batteryChart'), {{
    type: 'line',
    data: {{
      labels: batteryData.labels,
      datasets: [
        {{ label: 'Battery %', data: batteryData.percent, borderColor: '#D81E05', backgroundColor: 'rgba(216,30,5,0.08)', fill: true, tension: 0.3, pointRadius: 0 }},
        {{ label: 'Temp °C', data: batteryData.temp, borderColor: '#fbbf24', tension: 0.3, yAxisID: 'y1', pointRadius: 0 }}
      ]
    }},
    options: {{
      responsive: true,
      scales: {{
        y: {{ title: {{ display: true, text: 'Battery %' }}, ticks: {{ color: '#8b8f97' }}, grid: {{ color: '#22262e' }} }},
        y1: {{ position: 'right', title: {{ display: true, text: 'Temp °C' }}, ticks: {{ color: '#8b8f97' }}, grid: {{ drawOnChartArea: false }} }},
        x: {{ ticks: {{ color: '#8b8f97', maxTicksLimit: 20 }}, grid: {{ color: '#22262e' }} }}
      }},
      plugins: {{ legend: {{ labels: {{ color: '#f0f0f2' }} }} }}
    }}
  }});
}}

if (wifiData.labels.length) {{
  new Chart(document.getElementById('wifiChart'), {{
    type: 'line',
    data: {{
      labels: wifiData.labels,
      datasets: [{{ label: 'Signal %', data: wifiData.signal, borderColor: '#ffffff', backgroundColor: 'rgba(255,255,255,0.06)', fill: true, tension: 0.3, pointRadius: 0 }}]
    }},
    options: {{
      responsive: true,
      scales: {{
        y: {{ title: {{ display: true, text: 'Signal %' }}, min: 0, max: 100, ticks: {{ color: '#8b8f97' }}, grid: {{ color: '#22262e' }} }},
        x: {{ ticks: {{ color: '#8b8f97', maxTicksLimit: 20 }}, grid: {{ color: '#22262e' }} }}
      }},
      plugins: {{ legend: {{ labels: {{ color: '#f0f0f2' }} }} }}
    }}
  }});
}}
</script>
<div class="footer"><span class="brand">Honeywell</span> Data Log Parser · Hackathon 2026 — EMEA Team</div>
</body></html>"""


def _esc(val: Any) -> str:
    """Escape HTML special characters."""
    return str(val).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _health_class(score: int) -> str:
    if score >= 70:
        return "ok"
    if score >= 40:
        return "warn"
    return "crit"


def _battery_chart_data(timeline: list[dict]) -> dict:
    labels, percent, temp = [], [], []
    for r in timeline:
        labels.append(r.get("device_time", ""))
        percent.append(r.get("percent"))
        temp.append(r.get("temperature_c"))
    return {"labels": labels, "percent": percent, "temp": temp}


def _wifi_chart_data(timeline: list[dict]) -> dict:
    labels, signal = [], []
    for r in timeline:
        if r.get("signal_strength_pct") is not None:
            labels.append(r.get("device_time", ""))
            signal.append(r.get("signal_strength_pct"))
    return {"labels": labels, "signal": signal}
