"""Deterministic anomaly-detection engine.

Processes a stream of classified LogEvents and tags anomalies based on
configurable thresholds. Also produces session-level analytics.
"""

from __future__ import annotations

import dataclasses as dc
import re
from typing import Optional

from app import config
from app.parser import LogEvent

# Regex patterns for extracting data from event messages (used in anomaly engine)
_RE_CPU_VAL = re.compile(r"Average CPU usage during last minute:\s*([\d.]+)%", re.I)
_RE_RAM_VAL = re.compile(r"RAM \(heap\):\s*Load\s+(\d+)%,\s*Avail\s+(\d+)K,\s*Used\s+(\d+)K", re.I)
_RE_FLASH_VAL = re.compile(r"FLASH:\s*Avail\(Clean\)\s+(\d+)KB,\s*Used\s+(\d+)KB", re.I)
_RE_OPERATOR_VAL = re.compile(
    r"Current Operator ID\s*=\s*(\d+),\s*Current Operator Name\s*=\s*(.+?)(?:\s{2,}|\s*$)", re.I
)
_RE_HEADSET_VAL = re.compile(
    r"(SRX\s*\d+)\s+wireless headset is\s+(connected|disconnected)", re.I
)
_RE_RECOGNIZED_WORD_VAL = re.compile(r"Received new recognized word:\s*(.+)", re.I)
_RE_GWS_EXECUTE_STATE_VAL = re.compile(
    r"GWS:\s*ExecuteState\s*->\s*Current State Machine\s+(\S+),\s*Current State:\s*(\S+)\s+Trigger:\s*(\S+)",
    re.I,
)
_RE_DIALOG_ENTER_VAL = re.compile(
    r'Entering:\s*<Node \("([^"]+)"\)>\s*of dialog:\s*.*?\("([^"]+)"\)', re.I
)
_RE_RECOGNIZER_METHOD_VAL = re.compile(r"^[<>]\s+RecognizerServiceImpl::([A-Za-z0-9_]+)\(\)", re.I)
_RE_REX_EVENT_VAL = re.compile(r"^handling REX event:\s*([A-Z0-9_]+)", re.I)
_RE_VOICE_ARTISAN_VAL = re.compile(r"^(?:[<>]\s+)?VoiceArtisanTask::([A-Za-z0-9_]+)", re.I)
_RE_RECOGNIZER_STATUS_VAL = re.compile(r"^(Starting recognizer|Started recognizer|Stopping recognizer)\b", re.I)
_RE_CONTINUOUS_SOCKET_VAL = re.compile(
    r"Continuous Socket:\s*\[Host = ([^,]+), port = (\d+), Timeout = (\d+), Connection Count = (\d+), Error Count = (\d+)\]\s*(.+)",
    re.I,
)
_RE_PMS_MESSAGE_VAL = re.compile(r"^\[VCMainThread\]\s*got PMS message of type:\s*(\d+)", re.I)
_RE_CONFIG_CHANGE_VAL = re.compile(r"Found changed config item '([^']+)'", re.I)
_RE_VC_SEND_LOG_VAL = re.compile(
    r"\[VCSendLogData\]\s*Sending log messages to Voice Console, number characters\s*=\s*(\d+)",
    re.I,
)
_RE_SCANNER_EVENT_VAL = re.compile(
    r"^(Registering listener|Registering BLE Scanner Event Listener|Starting Scan|Exiting setScanCallback|Scan Canceled|Resetting scan queue and clearing old records|configureScanner - saw a scanning svc that wasn't serial or BLE)",
    re.I,
)
_RE_SRCOMM_COMMAND_VAL = re.compile(r"^SRCOMMWriter Sending command:\s*([^#]+)#:\s*(\d+)", re.I)
_RE_DIALOG_LIFECYCLE_VAL = re.compile(r"^(launch_dialog:\s*(begin|end)|Setting up transition to done state\.)", re.I)
_RE_DISPLAY_MESSAGE_VAL = re.compile(r"^\[DisplayMessageBrowserQueue\]\s*Message\s*=\s*(.+?)\s+type\s*=\s*(\d+)", re.I)
_RE_TTS_PROXY_VAL = re.compile(r"^[<>]\s+LanguageTtsServiceImplProxy::([A-Za-z0-9_]+)\(\)", re.I)

# Pass-3 anomaly-engine regex
_RE_SRX_LINK_STATUS_VAL = re.compile(
    r"^SRX link status\s*\|\s*quality low:\s*(\d+)\s+quality high:\s*(\d+)\s+quality avg:\s*(\d+)\s+"
    r"RSSI low:\s*(-?\d+)\s+RSSI high:\s*(-?\d+)\s+RSSI avg:\s*(-?\d+)",
    re.I,
)
_RE_ENTERING_DIALOG_VAL = re.compile(r'^Entering Dialog\s+\S+\s+\("([^"]+)"\)', re.I)
_RE_EXITING_DIALOG_VAL = re.compile(r'^(?:Exiting Dialog\s+\S+\s+\("([^"]+)"\)|Dialog\s+(\S+)\s+exiting\s+\(no more links\))', re.I)
_RE_TRANSITIONING_LINK_VAL = re.compile(r"^Transitioning through Link\s+(\S+)", re.I)
_RE_GWS_MESSAGE_BODY_VAL = re.compile(r'^GWS:\s*Message Body Received:\s*(.+)', re.I)
_RE_CHARGER_DETECT_VAL = re.compile(r"^EVDETCT:\s*ADC Level:\s*([\d.]+)v,\s*IN CHARGER", re.I)


@dc.dataclass
class AnomalyRecord:
    anomaly_type: str
    severity: str  # warning / critical
    description: str
    device_time: str = ""
    line_start: int = 0
    line_end: int = 0
    source_file: str = ""
    value: Optional[float] = None
    threshold: Optional[float] = None


class AnomalyEngine:
    """Stateful anomaly detector — feed events in chronological order."""

    def __init__(self) -> None:
        # Rolling state for battery
        self._last_battery_pct: Optional[float] = None
        self._last_battery_time: Optional[str] = None
        self._last_battery_mah: Optional[float] = None
        self._last_battery_mah_time: Optional[str] = None

        # Rolling state for wifi roaming
        self._recent_roams: list[str] = []  # device_time strings

        # Rolling state for RSSI_LOW bursts
        self._recent_rssi_low: list[str] = []  # device_time strings

        # Rolling state for data gaps
        self._last_device_time: Optional[str] = None

        # Rolling state for message loss
        self._in_loss_gap = False

        # Track battery swaps
        self._battery_swap_count = 0

        # Collected anomalies
        self.anomalies: list[AnomalyRecord] = []

        # Analytics accumulators
        self.battery_readings: list[dict] = []
        self.wifi_readings: list[dict] = []
        self.roam_events: list[dict] = []
        self.signal_events: list[dict] = []
        self.message_loss_events: list[dict] = []
        self.data_gap_events: list[dict] = []

        # New: System resource accumulators
        self.cpu_readings: list[dict] = []
        self.ram_readings: list[dict] = []
        self.flash_readings: list[dict] = []

        # New: Operator tracking
        self.operator_events: list[dict] = []
        self._last_operator_id: Optional[str] = None
        self._last_operator_name: Optional[str] = None

        # New: Headset tracking
        self.headset_events: list[dict] = []
        self._recent_headset_disconnects: list[str] = []

        # New: Voice recognition tracking
        self.voice_recognized_words: list[dict] = []
        self._say_again_count: int = 0
        self._total_recognized_words: int = 0
        self.speech_diagnostic_events: list[dict] = []

        # New: GWS workflow tracking
        self.gws_state_events: list[dict] = []
        self.gws_dialog_events: list[dict] = []

        # New: system transport / config diagnostics
        self.system_diagnostic_events: list[dict] = []

        # Pass-3 accumulators
        self.scanner_lifecycle_events: list[dict] = []
        self.bluetooth_lifecycle_events: list[dict] = []
        self.charger_detect_events: list[dict] = []
        self.srx_link_quality_events: list[dict] = []
        self.socket_error_events: list[dict] = []
        self.license_check_events: list[dict] = []
        self.dialog_workflow_events: list[dict] = []

    def process(self, ev: LogEvent) -> list[AnomalyRecord]:
        """Process one event and return any anomalies detected."""
        found: list[AnomalyRecord] = []

        # ── Data-gap detection ──────────────────────────────────────────
        if ev.device_time and self._last_device_time:
            try:
                cur_s = _time_to_seconds(ev.device_time)
                prev_s = _time_to_seconds(self._last_device_time)
                gap = cur_s - prev_s
                if gap > config.DATA_GAP_THRESHOLD_SEC:
                    rec = AnomalyRecord(
                        anomaly_type="data_gap",
                        severity="warning",
                        description=f"Data gap of {gap/60:.1f} minutes ({self._last_device_time} → {ev.device_time})",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=gap,
                        threshold=float(config.DATA_GAP_THRESHOLD_SEC),
                    )
                    found.append(rec)
                    self.data_gap_events.append({
                        "device_time": ev.device_time,
                        "gap_seconds": gap,
                        "line": ev.line_start,
                    })
            except (ValueError, IndexError):
                pass
        if ev.device_time:
            self._last_device_time = ev.device_time

        # ── Message loss ────────────────────────────────────────────────
        if ev.event_type == "messages_lost":
            self._in_loss_gap = True
            rec = AnomalyRecord(
                anomaly_type="messages_lost",
                severity="warning",
                description="Data gap: Messages lost marker detected",
                device_time=ev.device_time,
                line_start=ev.line_start,
                line_end=ev.line_end,
                source_file=ev.source_file,
            )
            found.append(rec)
            self.message_loss_events.append({
                "device_time": ev.device_time,
                "server_timestamp": ev.server_timestamp,
                "line": ev.line_start,
            })

        # Reset gap flag on next normal event
        if ev.event_type != "messages_lost" and self._in_loss_gap:
            self._in_loss_gap = False

        # ── Battery anomalies ───────────────────────────────────────────
        if ev.battery:
            b = ev.battery
            reading = {
                "device_time": ev.device_time,
                "server_timestamp": ev.server_timestamp,
                "line": ev.line_start,
            }

            if b.temperature_c is not None:
                reading["temperature_c"] = b.temperature_c
                if b.temperature_c >= config.TEMP_SPIKE_THRESHOLD_C:
                    rec = AnomalyRecord(
                        anomaly_type="temperature_spike",
                        severity="critical",
                        description=f"Temperature {b.temperature_c}°C exceeds {config.TEMP_SPIKE_THRESHOLD_C}°C",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=b.temperature_c,
                        threshold=config.TEMP_SPIKE_THRESHOLD_C,
                    )
                    found.append(rec)
                if b.temperature_c <= config.TEMP_COLD_THRESHOLD_C:
                    rec = AnomalyRecord(
                        anomaly_type="temperature_cold",
                        severity="warning",
                        description=f"Temperature {b.temperature_c}°C below {config.TEMP_COLD_THRESHOLD_C}°C (cold storage or sensor fault)",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=b.temperature_c,
                        threshold=config.TEMP_COLD_THRESHOLD_C,
                    )
                    found.append(rec)

            if b.percent is not None:
                reading["percent"] = b.percent
                if self._last_battery_pct is not None:
                    drop = self._last_battery_pct - b.percent
                    if drop >= config.BATTERY_DROP_THRESHOLD_PCT:
                        rec = AnomalyRecord(
                            anomaly_type="battery_drain_spike",
                            severity="warning",
                            description=f"Battery dropped {drop:.0f}% (from {self._last_battery_pct:.0f}% to {b.percent:.0f}%)",
                            device_time=ev.device_time,
                            line_start=ev.line_start,
                            line_end=ev.line_end,
                            source_file=ev.source_file,
                            value=drop,
                            threshold=float(config.BATTERY_DROP_THRESHOLD_PCT),
                        )
                        found.append(rec)
                    # Detect battery swaps (sudden large increase)
                    jump = b.percent - self._last_battery_pct
                    if jump >= config.BATTERY_SWAP_JUMP_PCT:
                        self._battery_swap_count += 1
                        rec = AnomalyRecord(
                            anomaly_type="battery_swap",
                            severity="notice",
                            description=f"Battery swap detected: {self._last_battery_pct:.0f}% → {b.percent:.0f}% (+{jump:.0f}%)",
                            device_time=ev.device_time,
                            line_start=ev.line_start,
                            line_end=ev.line_end,
                            source_file=ev.source_file,
                            value=jump,
                            threshold=float(config.BATTERY_SWAP_JUMP_PCT),
                        )
                        found.append(rec)
                # Critical low battery
                if b.percent <= config.BATTERY_CRITICAL_PCT:
                    rec = AnomalyRecord(
                        anomaly_type="low_battery_critical",
                        severity="critical",
                        description=f"Battery critically low at {b.percent:.0f}% (threshold: {config.BATTERY_CRITICAL_PCT}%)",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=b.percent,
                        threshold=float(config.BATTERY_CRITICAL_PCT),
                    )
                    found.append(rec)
                self._last_battery_pct = b.percent
                self._last_battery_time = ev.device_time

            if b.energy_consumption_mah is not None:
                reading["energy_mah"] = b.energy_consumption_mah
            if b.voltage_mv is not None:
                reading["voltage_mv"] = b.voltage_mv
            if b.current_ma is not None:
                reading["current_ma"] = b.current_ma
            if b.runtime_min is not None:
                reading["runtime_min"] = b.runtime_min

            self.battery_readings.append(reading)

        # ── Wi-Fi anomalies ─────────────────────────────────────────────
        if ev.wifi:
            w = ev.wifi

            if w.signal_strength_pct is not None:
                self.signal_events.append({
                    "device_time": ev.device_time,
                    "server_timestamp": ev.server_timestamp,
                    "signal_pct": w.signal_strength_pct,
                    "access_point": w.access_point,
                    "line": ev.line_start,
                })
                if w.signal_strength_pct <= config.WEAK_SIGNAL_THRESHOLD_PCT:
                    rec = AnomalyRecord(
                        anomaly_type="weak_signal",
                        severity="warning",
                        description=f"Wi-Fi coverage {w.signal_strength_pct}% fell below {config.WEAK_SIGNAL_THRESHOLD_PCT}%",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=float(w.signal_strength_pct),
                        threshold=float(config.WEAK_SIGNAL_THRESHOLD_PCT),
                    )
                    found.append(rec)

            if w.roamed_from and w.roamed_to:
                self._recent_roams.append(ev.device_time)
                self.roam_events.append({
                    "device_time": ev.device_time,
                    "server_timestamp": ev.server_timestamp,
                    "from_ap": w.roamed_from,
                    "to_ap": w.roamed_to,
                    "line": ev.line_start,
                })
                # Check rapid roaming
                self._trim_roam_window(ev.device_time)
                if len(self._recent_roams) >= config.ROAM_COUNT_THRESHOLD:
                    rec = AnomalyRecord(
                        anomaly_type="rapid_roaming",
                        severity="warning",
                        description=f"{len(self._recent_roams)} roams in {config.ROAM_WINDOW_SEC}s window",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=float(len(self._recent_roams)),
                        threshold=float(config.ROAM_COUNT_THRESHOLD),
                    )
                    found.append(rec)

            if w.connection_state == "failed":
                rec = AnomalyRecord(
                    anomaly_type="connection_failure",
                    severity="critical",
                    description="Wi-Fi connection failed",
                    device_time=ev.device_time,
                    line_start=ev.line_start,
                    line_end=ev.line_end,
                    source_file=ev.source_file,
                )
                found.append(rec)

            if w.rssi_event and "LOW" in w.rssi_event:
                self.wifi_readings.append({
                    "device_time": ev.device_time,
                    "server_timestamp": ev.server_timestamp,
                    "rssi_event": w.rssi_event,
                    "line": ev.line_start,
                })
                # RSSI_LOW burst detection
                self._recent_rssi_low.append(ev.device_time)
                self._trim_rssi_window(ev.device_time)
                if len(self._recent_rssi_low) >= config.RSSI_LOW_BURST_COUNT:
                    rec = AnomalyRecord(
                        anomaly_type="persistent_low_rssi",
                        severity="warning",
                        description=f"{len(self._recent_rssi_low)} low-coverage alerts in {config.RSSI_LOW_BURST_WINDOW_SEC}s window",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=float(len(self._recent_rssi_low)),
                        threshold=float(config.RSSI_LOW_BURST_COUNT),
                    )
                    found.append(rec)

        # ── System resource anomalies ───────────────────────────────────
        if ev.event_type == "cpu_usage":
            m = _RE_CPU_VAL.search(ev.message)
            if m:
                cpu_pct = float(m.group(1))
                self.cpu_readings.append({
                    "device_time": ev.device_time,
                    "cpu_pct": cpu_pct,
                    "line": ev.line_start,
                })
                if cpu_pct >= config.CPU_HIGH_THRESHOLD_PCT:
                    rec = AnomalyRecord(
                        anomaly_type="high_cpu",
                        severity="warning",
                        description=f"CPU usage {cpu_pct:.1f}% exceeds {config.CPU_HIGH_THRESHOLD_PCT}%",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=cpu_pct,
                        threshold=config.CPU_HIGH_THRESHOLD_PCT,
                    )
                    found.append(rec)

        if ev.event_type == "ram_usage":
            m = _RE_RAM_VAL.search(ev.message)
            if m:
                ram_load = int(m.group(1))
                ram_avail_kb = int(m.group(2))
                ram_used_kb = int(m.group(3))
                self.ram_readings.append({
                    "device_time": ev.device_time,
                    "load_pct": ram_load,
                    "avail_kb": ram_avail_kb,
                    "used_kb": ram_used_kb,
                    "line": ev.line_start,
                })
                if ram_load >= config.RAM_HIGH_THRESHOLD_PCT:
                    rec = AnomalyRecord(
                        anomaly_type="memory_pressure",
                        severity="warning",
                        description=f"RAM load {ram_load}% exceeds {config.RAM_HIGH_THRESHOLD_PCT}% (Avail {ram_avail_kb}K, Used {ram_used_kb}K)",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=float(ram_load),
                        threshold=float(config.RAM_HIGH_THRESHOLD_PCT),
                    )
                    found.append(rec)

        if ev.event_type == "flash_usage":
            m = _RE_FLASH_VAL.search(ev.message)
            if m:
                flash_avail_kb = int(m.group(1))
                flash_used_kb = int(m.group(2))
                total_kb = flash_avail_kb + flash_used_kb
                flash_used_pct = (flash_used_kb / total_kb * 100) if total_kb > 0 else 0
                self.flash_readings.append({
                    "device_time": ev.device_time,
                    "avail_kb": flash_avail_kb,
                    "used_kb": flash_used_kb,
                    "used_pct": round(flash_used_pct, 1),
                    "line": ev.line_start,
                })
                if flash_used_pct >= config.FLASH_HIGH_THRESHOLD_PCT:
                    rec = AnomalyRecord(
                        anomaly_type="flash_storage_high",
                        severity="warning",
                        description=f"Flash storage {flash_used_pct:.1f}% used ({flash_used_kb}KB / {total_kb}KB)",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                        value=flash_used_pct,
                        threshold=float(config.FLASH_HIGH_THRESHOLD_PCT),
                    )
                    found.append(rec)

        # ── Operator change detection ───────────────────────────────────
        if ev.event_type == "operator_login":
            m = _RE_OPERATOR_VAL.search(ev.message)
            if m:
                op_id = m.group(1).strip()
                op_name = m.group(2).strip()
                is_change = (
                    self._last_operator_id is not None
                    and self._last_operator_id != op_id
                )
                self.operator_events.append({
                    "device_time": ev.device_time,
                    "operator_id": op_id,
                    "operator_name": op_name,
                    "is_change": is_change,
                    "line": ev.line_start,
                })
                if is_change:
                    rec = AnomalyRecord(
                        anomaly_type="operator_change",
                        severity="notice",
                        description=f"Operator changed from {self._last_operator_name} to {op_name}",
                        device_time=ev.device_time,
                        line_start=ev.line_start,
                        line_end=ev.line_end,
                        source_file=ev.source_file,
                    )
                    found.append(rec)
                self._last_operator_id = op_id
                self._last_operator_name = op_name

        # ── Headset anomalies ───────────────────────────────────────────
        if ev.event_type in ("headset_connected", "headset_disconnected"):
            m = _RE_HEADSET_VAL.search(ev.message)
            headset_model = m.group(1) if m else "Unknown"
            status = "connected" if ev.event_type == "headset_connected" else "disconnected"
            self.headset_events.append({
                "device_time": ev.device_time,
                "model": headset_model,
                "status": status,
                "line": ev.line_start,
            })
            if status == "disconnected":
                rec = AnomalyRecord(
                    anomaly_type="headset_disconnect",
                    severity="warning",
                    description=f"{headset_model} wireless headset disconnected",
                    device_time=ev.device_time,
                    line_start=ev.line_start,
                    line_end=ev.line_end,
                    source_file=ev.source_file,
                )
                found.append(rec)

        # ── Voice recognition tracking ──────────────────────────────────
        if ev.event_type == "voice_recognized_word":
            m = _RE_RECOGNIZED_WORD_VAL.search(ev.message)
            if m:
                word = m.group(1).strip()
                self._total_recognized_words += 1
                if word.lower() == "say again":
                    self._say_again_count += 1
                self.voice_recognized_words.append({
                    "device_time": ev.device_time,
                    "word": word,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_recognizer_call":
            m = _RE_RECOGNIZER_METHOD_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "recognizer_call",
                    "name": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_rex_event":
            m = _RE_REX_EVENT_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "rex_event",
                    "name": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_voice_artisan":
            m = _RE_VOICE_ARTISAN_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "voice_artisan",
                    "name": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_grammar_event":
            self.speech_diagnostic_events.append({
                "kind": "grammar_event",
                "name": "grammar_reuse",
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        if ev.event_type == "speech_recognizer_lifecycle":
            m = _RE_RECOGNIZER_STATUS_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "recognizer_lifecycle",
                    "name": m.group(1).lower().replace(" ", "_"),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_utterance_state":
            self.speech_diagnostic_events.append({
                "kind": "utterance_state",
                "name": ev.message.strip(),
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        if ev.event_type == "speech_srcomm_command":
            m = _RE_SRCOMM_COMMAND_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "srcomm_command",
                    "name": m.group(1).strip(),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_recognizer_state":
            self.speech_diagnostic_events.append({
                "kind": "recognizer_state",
                "name": ev.message.strip(),
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        if ev.event_type == "speech_display_message":
            m = _RE_DISPLAY_MESSAGE_VAL.search(ev.message)
            if m:
                self.speech_diagnostic_events.append({
                    "kind": "display_message",
                    "name": m.group(2),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "speech_tts_event":
            m = _RE_TTS_PROXY_VAL.search(ev.message)
            name = m.group(1) if m else ev.message.strip()
            self.speech_diagnostic_events.append({
                "kind": "tts_event",
                "name": name,
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        if ev.event_type == "system_socket_activity":
            m = _RE_CONTINUOUS_SOCKET_VAL.search(ev.message)
            if m:
                self.system_diagnostic_events.append({
                    "kind": "socket_activity",
                    "host": m.group(1),
                    "port": int(m.group(2)),
                    "timeout": int(m.group(3)),
                    "connection_count": int(m.group(4)),
                    "error_count": int(m.group(5)),
                    "result": m.group(6).strip(),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "system_pms_message":
            m = _RE_PMS_MESSAGE_VAL.search(ev.message)
            if m:
                self.system_diagnostic_events.append({
                    "kind": "pms_message",
                    "message_type": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "system_config_change":
            m = _RE_CONFIG_CHANGE_VAL.search(ev.message)
            if m:
                self.system_diagnostic_events.append({
                    "kind": "config_change",
                    "item": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "system_voice_console_transfer":
            m = _RE_VC_SEND_LOG_VAL.search(ev.message)
            payload_size = int(m.group(1)) if m else None
            self.system_diagnostic_events.append({
                "kind": "voice_console_transfer",
                "payload_size": payload_size,
                "name": "send" if m else "success",
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        if ev.event_type == "system_scanner_event":
            m = _RE_SCANNER_EVENT_VAL.search(ev.message)
            if m:
                self.system_diagnostic_events.append({
                    "kind": "scanner_event",
                    "name": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "gws_dialog_lifecycle":
            m = _RE_DIALOG_LIFECYCLE_VAL.search(ev.message)
            if m:
                self.gws_dialog_events.append({
                    "device_time": ev.device_time,
                    "node": m.group(1),
                    "dialog": "dialog_lifecycle",
                    "line": ev.line_start,
                })

        # ── Pass-3: Scanner lifecycle tracking ──────────────────────────
        if ev.event_type == "scanner_lifecycle":
            self.scanner_lifecycle_events.append({
                "device_time": ev.device_time,
                "message": ev.message[:120],
                "line": ev.line_start,
            })

        # ── Pass-3: Bluetooth lifecycle tracking ────────────────────────
        if ev.event_type == "bluetooth_lifecycle":
            self.bluetooth_lifecycle_events.append({
                "device_time": ev.device_time,
                "message": ev.message[:120],
                "line": ev.line_start,
            })

        # ── Pass-3: Charger detection tracking ─────────────────────────
        if ev.event_type == "battery_charger_detect":
            m = _RE_CHARGER_DETECT_VAL.search(ev.message)
            voltage = float(m.group(1)) if m else None
            self.charger_detect_events.append({
                "device_time": ev.device_time,
                "voltage_v": voltage,
                "line": ev.line_start,
            })

        # ── Pass-3: SRX headset link quality tracking ──────────────────
        if ev.event_type == "headset_srx_link_quality":
            m = _RE_SRX_LINK_STATUS_VAL.search(ev.message)
            if m:
                self.srx_link_quality_events.append({
                    "device_time": ev.device_time,
                    "quality_low": int(m.group(1)),
                    "quality_high": int(m.group(2)),
                    "quality_avg": int(m.group(3)),
                    "rssi_low": int(m.group(4)),
                    "rssi_high": int(m.group(5)),
                    "rssi_avg": int(m.group(6)),
                    "line": ev.line_start,
                })

        # ── Pass-3: Socket error tracking ──────────────────────────────
        if ev.event_type == "system_socket_error":
            self.socket_error_events.append({
                "device_time": ev.device_time,
                "message": ev.message[:200],
                "line": ev.line_start,
            })
            # Generate anomaly for connection-refused errors
            if "ConnectionRefusedError" in ev.message:
                rec = AnomalyRecord(
                    anomaly_type="voice_console_connection_refused",
                    severity="warning",
                    description="Voice Console socket connection refused — device may lose logging and task data",
                    device_time=ev.device_time,
                    line_start=ev.line_start,
                    line_end=ev.line_end,
                    source_file=ev.source_file,
                )
                found.append(rec)

        # ── Pass-3: License check tracking ─────────────────────────────
        if ev.event_type == "system_license_check":
            self.license_check_events.append({
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        # ── Pass-3: Dialog workflow tracking ────────────────────────────
        if ev.event_type == "gws_dialog_enter":
            m = _RE_ENTERING_DIALOG_VAL.search(ev.message)
            if m:
                self.dialog_workflow_events.append({
                    "kind": "enter",
                    "dialog": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })
                # Also track in gws_dialog_events for existing summary
                self.gws_dialog_events.append({
                    "device_time": ev.device_time,
                    "node": m.group(1),
                    "dialog": m.group(1),
                    "line": ev.line_start,
                })

        if ev.event_type == "gws_dialog_exit":
            m = _RE_EXITING_DIALOG_VAL.search(ev.message)
            if m:
                dialog_name = m.group(1) or m.group(2) or ""
                self.dialog_workflow_events.append({
                    "kind": "exit",
                    "dialog": dialog_name,
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "gws_link_transition":
            m = _RE_TRANSITIONING_LINK_VAL.search(ev.message)
            if m:
                self.dialog_workflow_events.append({
                    "kind": "transition",
                    "link": m.group(1),
                    "device_time": ev.device_time,
                    "line": ev.line_start,
                })

        if ev.event_type == "gws_message_body":
            self.dialog_workflow_events.append({
                "kind": "message_body",
                "device_time": ev.device_time,
                "line": ev.line_start,
            })

        # ── GWS workflow tracking ───────────────────────────────────────
        if ev.event_type == "gws_execute_state":
            m = _RE_GWS_EXECUTE_STATE_VAL.search(ev.message)
            if m:
                self.gws_state_events.append({
                    "device_time": ev.device_time,
                    "state_machine": m.group(1),
                    "state": m.group(2),
                    "trigger": m.group(3),
                    "line": ev.line_start,
                })

        if ev.event_type == "gws_dialog_enter":
            m = _RE_DIALOG_ENTER_VAL.search(ev.message)
            if m:
                self.gws_dialog_events.append({
                    "device_time": ev.device_time,
                    "node": m.group(1),
                    "dialog": m.group(2),
                    "line": ev.line_start,
                })

        # Tag the event
        if found:
            codes = [r.anomaly_type for r in found]
            ev.anomalies = ",".join(codes)
            ev.severity = max(
                (r.severity for r in found),
                key=lambda s: {"info": 0, "notice": 1, "warning": 2, "critical": 3}.get(s, 0),
            )
        self.anomalies.extend(found)
        return found

    def _trim_roam_window(self, current_time: str) -> None:
        """Remove roam entries outside the window. Uses simple string comparison
        since device_time is HH:MM:SS.mmm format."""
        if not self._recent_roams or not current_time:
            return
        try:
            cur = _time_to_seconds(current_time)
            self._recent_roams = [
                t for t in self._recent_roams
                if cur - _time_to_seconds(t) <= config.ROAM_WINDOW_SEC
            ]
        except (ValueError, IndexError):
            pass

    def _trim_rssi_window(self, current_time: str) -> None:
        """Remove RSSI_LOW entries outside the burst detection window."""
        if not self._recent_rssi_low or not current_time:
            return
        try:
            cur = _time_to_seconds(current_time)
            self._recent_rssi_low = [
                t for t in self._recent_rssi_low
                if cur - _time_to_seconds(t) <= config.RSSI_LOW_BURST_WINDOW_SEC
            ]
        except (ValueError, IndexError):
            pass

    def summary(self) -> dict:
        """Produce session-level analytics summary."""
        anomaly_counts: dict[str, int] = {}
        for a in self.anomalies:
            anomaly_counts[a.anomaly_type] = anomaly_counts.get(a.anomaly_type, 0) + 1

        # Battery analytics
        temps = [r["temperature_c"] for r in self.battery_readings if "temperature_c" in r]
        percents = [r["percent"] for r in self.battery_readings if "percent" in r]
        runtimes = [r["runtime_min"] for r in self.battery_readings if "runtime_min" in r]

        battery_summary = {}
        if temps:
            battery_summary["temp_min"] = min(temps)
            battery_summary["temp_max"] = max(temps)
            battery_summary["temp_avg"] = sum(temps) / len(temps)
        if percents:
            battery_summary["percent_start"] = percents[0]
            battery_summary["percent_end"] = percents[-1]
            battery_summary["total_drain"] = percents[0] - percents[-1]
            # Distinguish charging vs draining
            if percents[-1] > percents[0]:
                battery_summary["charging"] = True
                battery_summary["net_charge_pct"] = percents[-1] - percents[0]
            else:
                battery_summary["charging"] = False
                battery_summary["net_drain_pct"] = percents[0] - percents[-1]
        if runtimes:
            battery_summary["runtime_start"] = runtimes[0]
            battery_summary["runtime_end"] = runtimes[-1]
        battery_summary["swap_count"] = self._battery_swap_count

        # Charge/discharge cycle analysis from current_ma readings
        currents = [r.get("current_ma") for r in self.battery_readings if r.get("current_ma") is not None]
        if currents:
            charging_samples = sum(1 for c in currents if c > 0)
            discharging_samples = sum(1 for c in currents if c < 0)
            battery_summary["charging_samples"] = charging_samples
            battery_summary["discharging_samples"] = discharging_samples
            battery_summary["avg_discharge_ma"] = round(
                sum(c for c in currents if c < 0) / discharging_samples, 1
            ) if discharging_samples else 0
            battery_summary["avg_charge_ma"] = round(
                sum(c for c in currents if c > 0) / charging_samples, 1
            ) if charging_samples else 0

        # WiFi analytics
        signals = [r["signal_pct"] for r in self.signal_events]
        wifi_summary = {}
        if signals:
            wifi_summary["signal_min"] = min(signals)
            wifi_summary["signal_max"] = max(signals)
            wifi_summary["signal_avg"] = sum(signals) / len(signals)
        wifi_summary["total_roams"] = len(self.roam_events)
        wifi_summary["total_rssi_low"] = sum(
            1 for r in self.wifi_readings if r.get("rssi_event") == "RSSI_LOW"
        )

        # AP stability
        ap_roam_counts: dict[str, int] = {}
        for r in self.roam_events:
            for ap in (r.get("from_ap", ""), r.get("to_ap", "")):
                if ap:
                    ap_roam_counts[ap] = ap_roam_counts.get(ap, 0) + 1
        top_unstable_aps = sorted(ap_roam_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        # ── System resource analytics ───────────────────────────────────
        system_summary = {}
        if self.cpu_readings:
            cpu_vals = [r["cpu_pct"] for r in self.cpu_readings]
            system_summary["cpu_min"] = round(min(cpu_vals), 1)
            system_summary["cpu_max"] = round(max(cpu_vals), 1)
            system_summary["cpu_avg"] = round(sum(cpu_vals) / len(cpu_vals), 1)
            system_summary["cpu_samples"] = len(cpu_vals)
            system_summary["cpu_high_count"] = sum(1 for v in cpu_vals if v >= config.CPU_HIGH_THRESHOLD_PCT)

        if self.ram_readings:
            ram_loads = [r["load_pct"] for r in self.ram_readings]
            system_summary["ram_load_min"] = min(ram_loads)
            system_summary["ram_load_max"] = max(ram_loads)
            system_summary["ram_load_avg"] = round(sum(ram_loads) / len(ram_loads), 1)
            system_summary["ram_samples"] = len(ram_loads)
            system_summary["ram_high_count"] = sum(1 for v in ram_loads if v >= config.RAM_HIGH_THRESHOLD_PCT)

        if self.flash_readings:
            flash_used = [r["used_pct"] for r in self.flash_readings]
            system_summary["flash_used_min"] = round(min(flash_used), 1)
            system_summary["flash_used_max"] = round(max(flash_used), 1)
            system_summary["flash_used_avg"] = round(sum(flash_used) / len(flash_used), 1)
            system_summary["flash_samples"] = len(flash_used)

        if self.system_diagnostic_events:
            socket_events = [e for e in self.system_diagnostic_events if e["kind"] == "socket_activity"]
            pms_events = [e for e in self.system_diagnostic_events if e["kind"] == "pms_message"]
            config_events = [e for e in self.system_diagnostic_events if e["kind"] == "config_change"]

            if socket_events:
                system_summary["voice_console_transfers"] = len(socket_events)
                system_summary["voice_console_max_errors"] = max(e["error_count"] for e in socket_events)
                hosts = {}
                for event in socket_events:
                    key = f"{event['host']}:{event['port']}"
                    hosts[key] = hosts.get(key, 0) + 1
                system_summary["voice_console_hosts"] = sorted(hosts.items(), key=lambda item: -item[1])[:5]

            if pms_events:
                system_summary["pms_message_count"] = len(pms_events)
                pms_counts: dict[str, int] = {}
                for event in pms_events:
                    pms_type = event["message_type"]
                    pms_counts[pms_type] = pms_counts.get(pms_type, 0) + 1
                system_summary["pms_message_types"] = sorted(pms_counts.items(), key=lambda item: -item[1])[:10]

            if config_events:
                system_summary["config_change_count"] = len(config_events)
                config_counts: dict[str, int] = {}
                for event in config_events:
                    item = event["item"]
                    config_counts[item] = config_counts.get(item, 0) + 1
                system_summary["config_changes"] = sorted(config_counts.items(), key=lambda item: -item[1])[:10]

            transfer_events = [e for e in self.system_diagnostic_events if e["kind"] == "voice_console_transfer"]
            if transfer_events:
                system_summary["voice_console_send_count"] = sum(1 for e in transfer_events if e["name"] == "send")
                system_summary["voice_console_success_count"] = sum(1 for e in transfer_events if e["name"] == "success")
                payload_sizes = [e["payload_size"] for e in transfer_events if e.get("payload_size") is not None]
                if payload_sizes:
                    system_summary["voice_console_avg_payload"] = round(sum(payload_sizes) / len(payload_sizes), 1)

            scanner_events = [e for e in self.system_diagnostic_events if e["kind"] == "scanner_event"]
            if scanner_events:
                system_summary["scanner_event_count"] = len(scanner_events)
                scanner_counts: dict[str, int] = {}
                for event in scanner_events:
                    name = event["name"]
                    scanner_counts[name] = scanner_counts.get(name, 0) + 1
                system_summary["scanner_events"] = sorted(scanner_counts.items(), key=lambda item: -item[1])[:10]

        # ── Operator analytics ──────────────────────────────────────────
        operator_summary = {}
        if self.operator_events:
            unique_operators = {}
            for e in self.operator_events:
                oid = e["operator_id"]
                if oid not in unique_operators:
                    unique_operators[oid] = e["operator_name"]
            operator_summary["unique_operators"] = len(unique_operators)
            operator_summary["operator_list"] = [
                {"id": oid, "name": name} for oid, name in unique_operators.items()
            ]
            operator_summary["operator_changes"] = sum(1 for e in self.operator_events if e.get("is_change"))

        # ── Headset analytics ───────────────────────────────────────────
        headset_summary = {}
        if self.headset_events:
            connected = sum(1 for e in self.headset_events if e["status"] == "connected")
            disconnected = sum(1 for e in self.headset_events if e["status"] == "disconnected")
            models = set(e["model"] for e in self.headset_events)
            headset_summary["connected_count"] = connected
            headset_summary["disconnected_count"] = disconnected
            headset_summary["total_events"] = len(self.headset_events)
            headset_summary["models"] = list(models)

        # ── Voice recognition analytics ─────────────────────────────────
        voice_summary = {}
        if self._total_recognized_words > 0:
            voice_summary["total_recognized"] = self._total_recognized_words
            voice_summary["say_again_count"] = self._say_again_count
            voice_summary["say_again_rate"] = round(
                (self._say_again_count / self._total_recognized_words) * 100, 2
            )
            # Unique words
            word_counts: dict[str, int] = {}
            for e in self.voice_recognized_words:
                w = e["word"]
                word_counts[w] = word_counts.get(w, 0) + 1
            voice_summary["unique_words"] = len(word_counts)
            voice_summary["top_words"] = sorted(word_counts.items(), key=lambda x: -x[1])[:10]

        if self.speech_diagnostic_events:
            recognizer_methods: dict[str, int] = {}
            rex_counts: dict[str, int] = {}
            voice_artisan_counts: dict[str, int] = {}
            lifecycle_counts: dict[str, int] = {}
            srcomm_counts: dict[str, int] = {}
            display_counts: dict[str, int] = {}
            tts_counts: dict[str, int] = {}

            for event in self.speech_diagnostic_events:
                kind = event["kind"]
                name = event["name"]
                if kind == "recognizer_call":
                    recognizer_methods[name] = recognizer_methods.get(name, 0) + 1
                elif kind == "rex_event":
                    rex_counts[name] = rex_counts.get(name, 0) + 1
                elif kind == "voice_artisan":
                    voice_artisan_counts[name] = voice_artisan_counts.get(name, 0) + 1
                elif kind == "recognizer_lifecycle":
                    lifecycle_counts[name] = lifecycle_counts.get(name, 0) + 1
                elif kind == "srcomm_command":
                    srcomm_counts[name] = srcomm_counts.get(name, 0) + 1
                elif kind == "display_message":
                    display_counts[name] = display_counts.get(name, 0) + 1
                elif kind == "tts_event":
                    tts_counts[name] = tts_counts.get(name, 0) + 1

            if recognizer_methods:
                voice_summary["recognizer_call_count"] = sum(recognizer_methods.values())
                voice_summary["recognizer_methods"] = sorted(recognizer_methods.items(), key=lambda item: -item[1])[:10]

            if rex_counts:
                voice_summary["rex_event_count"] = sum(rex_counts.values())
                voice_summary["rex_events"] = sorted(rex_counts.items(), key=lambda item: -item[1])[:10]

            if voice_artisan_counts:
                voice_summary["voice_artisan_event_count"] = sum(voice_artisan_counts.values())
                voice_summary["voice_artisan_events"] = sorted(voice_artisan_counts.items(), key=lambda item: -item[1])[:10]

            if lifecycle_counts:
                voice_summary["recognizer_lifecycle"] = lifecycle_counts
                voice_summary["recognizer_cycles_started"] = lifecycle_counts.get("starting_recognizer", 0) + lifecycle_counts.get("started_recognizer", 0)
                voice_summary["recognizer_cycles_stopped"] = lifecycle_counts.get("stopping_recognizer", 0)

            if srcomm_counts:
                voice_summary["srcomm_command_count"] = sum(srcomm_counts.values())
                voice_summary["srcomm_commands"] = sorted(srcomm_counts.items(), key=lambda item: -item[1])[:10]

            if display_counts:
                voice_summary["display_message_count"] = sum(display_counts.values())
                voice_summary["display_message_types"] = sorted(display_counts.items(), key=lambda item: -item[1])[:10]

            if tts_counts:
                voice_summary["tts_event_count"] = sum(tts_counts.values())
                voice_summary["tts_events"] = sorted(tts_counts.items(), key=lambda item: -item[1])[:10]

            voice_summary["grammar_reuse_count"] = sum(
                1 for event in self.speech_diagnostic_events if event["kind"] == "grammar_event"
            )

        # ── GWS workflow analytics ──────────────────────────────────────
        workflow_summary = {}
        if self.gws_state_events:
            state_machine_counts: dict[str, int] = {}
            for e in self.gws_state_events:
                sm = e["state_machine"]
                state_machine_counts[sm] = state_machine_counts.get(sm, 0) + 1
            workflow_summary["total_state_transitions"] = len(self.gws_state_events)
            workflow_summary["state_machines"] = sorted(
                state_machine_counts.items(), key=lambda x: -x[1]
            )[:10]
        if self.gws_dialog_events:
            dialog_counts: dict[str, int] = {}
            for e in self.gws_dialog_events:
                d = e["dialog"]
                dialog_counts[d] = dialog_counts.get(d, 0) + 1
            workflow_summary["total_dialog_entries"] = len(self.gws_dialog_events)
            workflow_summary["dialogs"] = sorted(
                dialog_counts.items(), key=lambda x: -x[1]
            )[:10]

        # Estimate picks/hour from PickPrompt state machine
        if self.gws_state_events:
            pick_events = [
                e for e in self.gws_state_events
                if "Pick" in e.get("state_machine", "")
                and e.get("trigger") == "ReturnUserInput"
            ]
            if pick_events and pick_events[0].get("device_time") and pick_events[-1].get("device_time"):
                try:
                    t_start = _time_to_seconds(pick_events[0]["device_time"])
                    t_end = _time_to_seconds(pick_events[-1]["device_time"])
                    duration_hrs = (t_end - t_start) / 3600
                    if duration_hrs > 0:
                        workflow_summary["picks_total"] = len(pick_events)
                        workflow_summary["picks_per_hour"] = round(len(pick_events) / duration_hrs, 1)
                        workflow_summary["pick_duration_hrs"] = round(duration_hrs, 2)
                except (ValueError, IndexError):
                    pass

        # ── Pass-3: Dialog flow analytics ───────────────────────────────
        if self.dialog_workflow_events:
            enter_counts: dict[str, int] = {}
            link_counts: dict[str, int] = {}
            for e in self.dialog_workflow_events:
                if e["kind"] == "enter":
                    d = e.get("dialog", "unknown")
                    enter_counts[d] = enter_counts.get(d, 0) + 1
                elif e["kind"] == "transition":
                    lnk = e.get("link", "unknown")
                    link_counts[lnk] = link_counts.get(lnk, 0) + 1
            if enter_counts:
                workflow_summary["dialog_enter_counts"] = sorted(enter_counts.items(), key=lambda x: -x[1])[:10]
            workflow_summary["total_link_transitions"] = sum(link_counts.values())
            if link_counts:
                workflow_summary["top_links"] = sorted(link_counts.items(), key=lambda x: -x[1])[:10]
            gws_msg_body_count = sum(1 for e in self.dialog_workflow_events if e["kind"] == "message_body")
            if gws_msg_body_count:
                workflow_summary["gws_message_body_count"] = gws_msg_body_count

        # ── Pass-3: Scanner analytics ───────────────────────────────────
        scanner_summary = {}
        if self.scanner_lifecycle_events:
            scanner_summary["total_events"] = len(self.scanner_lifecycle_events)

        # ── Pass-3: Bluetooth analytics ─────────────────────────────────
        bluetooth_summary = {}
        if self.bluetooth_lifecycle_events:
            bluetooth_summary["total_events"] = len(self.bluetooth_lifecycle_events)

        # ── Pass-3: Charger analytics ───────────────────────────────────
        charger_summary = {}
        if self.charger_detect_events:
            charger_summary["total_events"] = len(self.charger_detect_events)
            voltages = [e["voltage_v"] for e in self.charger_detect_events if e.get("voltage_v") is not None]
            if voltages:
                charger_summary["voltage_avg"] = round(sum(voltages) / len(voltages), 2)
                charger_summary["voltage_min"] = round(min(voltages), 2)
                charger_summary["voltage_max"] = round(max(voltages), 2)

        # ── Pass-3: SRX link quality analytics ──────────────────────────
        srx_summary = {}
        if self.srx_link_quality_events:
            srx_summary["total_reports"] = len(self.srx_link_quality_events)
            q_avgs = [e["quality_avg"] for e in self.srx_link_quality_events]
            r_avgs = [e["rssi_avg"] for e in self.srx_link_quality_events]
            srx_summary["quality_avg"] = round(sum(q_avgs) / len(q_avgs), 1)
            srx_summary["quality_min"] = min(q_avgs)
            srx_summary["quality_max"] = max(q_avgs)
            srx_summary["rssi_avg"] = round(sum(r_avgs) / len(r_avgs), 1)
            srx_summary["rssi_min"] = min(r_avgs)
            srx_summary["rssi_max"] = max(r_avgs)

        # ── Pass-3: Socket error analytics ──────────────────────────────
        socket_summary = {}
        if self.socket_error_events:
            socket_summary["total_errors"] = len(self.socket_error_events)

        # ── Pass-3: License check analytics ─────────────────────────────
        license_summary = {}
        if self.license_check_events:
            license_summary["total_checks"] = len(self.license_check_events)

        # ── Pass-3: Dialog flow summary (separate from workflow for UI) ──
        dialog_flow_summary: dict = {}
        if self.dialog_workflow_events:
            enters = [e for e in self.dialog_workflow_events if e["kind"] == "enter"]
            transitions = [e for e in self.dialog_workflow_events if e["kind"] == "transition"]
            dialog_flow_summary["total_enters"] = len(enters)
            dialog_flow_summary["total_links"] = len(transitions)
            if enters:
                dialog_counts: dict[str, int] = {}
                for e in enters:
                    d = e.get("dialog", "unknown")
                    dialog_counts[d] = dialog_counts.get(d, 0) + 1
                top = max(dialog_counts.items(), key=lambda x: x[1])
                dialog_flow_summary["top_dialog"] = top[0]

        return {
            "anomaly_counts": anomaly_counts,
            "total_anomalies": len(self.anomalies),
            "battery": battery_summary,
            "wifi": wifi_summary,
            "system": system_summary,
            "operator": operator_summary,
            "headset": headset_summary,
            "voice": voice_summary,
            "workflow": workflow_summary,
            "top_unstable_aps": top_unstable_aps,
            "message_loss_count": len(self.message_loss_events),
            "data_gap_count": len(self.data_gap_events),
            "scanner": scanner_summary,
            "bluetooth": bluetooth_summary,
            "charger": charger_summary,
            "srx_link_quality": srx_summary,
            "socket_errors": socket_summary,
            "licensing": license_summary,
            "dialog_flow": dialog_flow_summary,
        }


def _time_to_seconds(t: str) -> float:
    """Convert HH:MM:SS.mmm to seconds."""
    parts = t.split(":")
    h, m = int(parts[0]), int(parts[1])
    s = float(parts[2])
    return h * 3600 + m * 60 + s
