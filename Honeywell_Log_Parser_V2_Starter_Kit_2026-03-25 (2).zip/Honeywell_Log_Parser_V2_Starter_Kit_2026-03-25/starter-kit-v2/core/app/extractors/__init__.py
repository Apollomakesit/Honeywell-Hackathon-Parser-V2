"""Event classification and metric extraction.

Each extractor inspects a LogEvent's message and populates its component,
event_type, severity, and domain-specific metrics (battery / wifi).
"""

from __future__ import annotations

import re
from app.parser import BatteryMetrics, LogEvent, WifiMetrics


# ── Battery extractors ──────────────────────────────────────────────────────

_RE_BATTERY_RUNTIME = re.compile(r"Battery runtime remaining:\s*(\d+)\s*minutes", re.I)
_RE_BATTERY_PERCENT = re.compile(r"Battery percent remaining:\s*(\d+)", re.I)
_RE_BATTERY_PROPS = re.compile(
    r"\[TTE \(min\):\s*(\d+)\].*?"
    r"\[PercentCharge:\s*(\d+)%?\].*?"
    r"\[Volts:\s*([\d.]+)\].*?"
    r"\[EnergyConsumption:\s*([-\d.]+)\s*mAh\].*?"
    r"\[Temperature:\s*([-\d.]+)\s*deg\s*C\]",
    re.I | re.S,
)
_RE_BATMON = re.compile(
    r"BATMON:\s*([\d.]+)\s*mV\s+([-\d.]+)\s*mA\s+([-\d.]+)\s*C", re.I
)


def extract_battery(ev: LogEvent) -> bool:
    """Try to extract battery metrics. Returns True if matched."""
    msg = ev.message

    m = _RE_BATTERY_PROPS.search(msg)
    if m:
        try:
            ev.component = "battery"
            ev.event_type = "battery_properties"
            ev.battery = BatteryMetrics(
                runtime_min=float(m.group(1)),
                percent=float(m.group(2)),
                voltage_mv=float(m.group(3)) * 1000,
                energy_consumption_mah=float(m.group(4)),
                temperature_c=float(m.group(5)),
            )
            return True
        except ValueError:
            pass  # malformed values in log

    m = _RE_BATMON.search(msg)
    if m:
        try:
            ev.component = "battery"
            ev.event_type = "batmon_telemetry"
            ev.battery = BatteryMetrics(
                voltage_mv=float(m.group(1)),
                current_ma=float(m.group(2)),
                temperature_c=float(m.group(3)),
            )
            return True
        except ValueError:
            pass  # malformed telemetry in log

    m = _RE_BATTERY_RUNTIME.search(msg)
    if m:
        ev.component = "battery"
        ev.event_type = "battery_runtime"
        ev.battery = BatteryMetrics(runtime_min=float(m.group(1)))
        return True

    m = _RE_BATTERY_PERCENT.search(msg)
    if m:
        ev.component = "battery"
        ev.event_type = "battery_percent"
        ev.battery = BatteryMetrics(percent=float(m.group(1)))
        return True

    return False


# ── Wi-Fi extractors ────────────────────────────────────────────────────────

_RE_SURVEY_AP = re.compile(r"SURVEY:\s*Access Point:\s*([\w:]+)", re.I)
_RE_SURVEY_SIGNAL = re.compile(
    r"SURVEY:\s*Signal Strength:\s*(\d+)%\s*\(([^)]+)\)", re.I
)
_RE_ROAMED = re.compile(
    r"AP MON:\s*ROAMED from AP\s+([\w:]+)\s+to AP\s+([\w:]+)", re.I
)
_RE_CONNECTED_BSSID = re.compile(r"Connected to bssid\s+([\w:]+)", re.I)
_RE_CONNECTION_FAILED = re.compile(r"Connection Failed", re.I)
_RE_RSSI_EVENT = re.compile(r"Beacon (RSSI_(?:LOW|HIGH))", re.I)
_RE_SCHED_SCAN_START = re.compile(r"sched_scan_start", re.I)
_RE_SCHED_SCAN_RESULT = re.compile(r"Report sched_scan result", re.I)
_RE_MEDIA_CONNECT = re.compile(r"Media Connect Status:\s*(\w+)", re.I)


def extract_wifi(ev: LogEvent) -> bool:
    """Try to extract Wi-Fi metrics. Returns True if matched."""
    msg = ev.message

    m = _RE_SURVEY_SIGNAL.search(msg)
    if m:
        ev.component = "wifi"
        ev.event_type = "wifi_survey_signal"
        ev.wifi = WifiMetrics(
            signal_strength_pct=int(m.group(1)),
            signal_samples=m.group(2).strip(),
        )
        return True

    m = _RE_SURVEY_AP.search(msg)
    if m:
        ev.component = "wifi"
        ev.event_type = "wifi_survey_ap"
        ev.wifi = WifiMetrics(access_point=m.group(1))
        return True

    m = _RE_ROAMED.search(msg)
    if m:
        ev.component = "wifi"
        ev.event_type = "wifi_roam"
        ev.severity = "notice"
        ev.wifi = WifiMetrics(roamed_from=m.group(1), roamed_to=m.group(2))
        return True

    m = _RE_CONNECTED_BSSID.search(msg)
    if m:
        ev.component = "wifi"
        ev.event_type = "wifi_connected"
        ev.wifi = WifiMetrics(bssid=m.group(1), connection_state="connected")
        return True

    if _RE_CONNECTION_FAILED.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_connection_failed"
        ev.severity = "error"
        ev.wifi = WifiMetrics(connection_state="failed")
        return True

    m = _RE_RSSI_EVENT.search(msg)
    if m:
        ev.component = "wifi"
        rssi_type = m.group(1).upper()
        ev.event_type = "wifi_rssi_event"
        ev.severity = "warning" if "LOW" in rssi_type else "info"
        ev.wifi = WifiMetrics(rssi_event=rssi_type)
        return True

    if _RE_SCHED_SCAN_START.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_scan_start"
        ev.wifi = WifiMetrics(scan_event="sched_scan_start")
        return True

    if _RE_SCHED_SCAN_RESULT.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_scan_result"
        ev.wifi = WifiMetrics(scan_event="sched_scan_result")
        return True

    m = _RE_MEDIA_CONNECT.search(msg)
    if m:
        ev.component = "wifi"
        ev.event_type = "media_connect_status"
        ev.wifi = WifiMetrics(connection_state=m.group(1).lower())
        return True

    return False


# ── GWS / system / other classifiers ────────────────────────────────────────

_RE_GWS = re.compile(r"^GWS:", re.I)
_RE_PLATFORM = re.compile(r"^PLATFORM LOG:", re.I)
_RE_SPCHDET = re.compile(r"^SPCHDET:", re.I)
_RE_RECOG = re.compile(r"^(?:Recognition message|RecogEvent|DECODER)", re.I)
_RE_MESSAGES_LOST = re.compile(r"WARNING!\s*Messages lost!", re.I)

# ── System resource extractors ──────────────────────────────────────────────

_RE_CPU_USAGE = re.compile(
    r"Average CPU usage during last minute:\s*([\d.]+)%", re.I
)
_RE_RAM_USAGE = re.compile(
    r"RAM \(heap\):\s*Load\s+(\d+)%,\s*Avail\s+(\d+)K,\s*Used\s+(\d+)K", re.I
)
_RE_FLASH_USAGE = re.compile(
    r"FLASH:\s*Avail\(Clean\)\s+(\d+)KB,\s*Used\s+(\d+)KB", re.I
)
_RE_CONTINUOUS_SOCKET = re.compile(
    r"Continuous Socket:\s*\[Host = ([^,]+), port = (\d+), Timeout = (\d+), Connection Count = (\d+), Error Count = (\d+)\]\s*(.+)",
    re.I,
)
_RE_PMS_MESSAGE = re.compile(r"\[VCMainThread\]\s*got PMS message of type:\s*(\d+)", re.I)
_RE_CONFIG_CHANGE = re.compile(r"Found changed config item '([^']+)'", re.I)
_RE_VC_SEND_LOG = re.compile(
    r"\[VCSendLogData\]\s*Sending log messages to Voice Console, number characters\s*=\s*(\d+)",
    re.I,
)
_RE_VC_SEND_SUCCESS = re.compile(r"\[VCSendLogData\]\s*Got Send Successful Event", re.I)
_RE_SCANNER_EVENT = re.compile(
    r"^(Registering listener|Registering BLE Scanner Event Listener|Starting Scan|Exiting setScanCallback|Scan Canceled|Resetting scan queue and clearing old records|configureScanner - saw a scanning svc that wasn't serial or BLE)",
    re.I,
)
_RE_BATTERY_IDENTIFIER = re.compile(r"^Battery\s+\d+:[0-9A-Fa-f]+$", re.I)

# ── Operator / headset extractors ───────────────────────────────────────────

_RE_OPERATOR = re.compile(
    r"Current Operator ID\s*=\s*(\d+),\s*Current Operator Name\s*=\s*(.+?)(?:\s{2,}|\s*$)",
    re.I,
)
_RE_HEADSET = re.compile(
    r"(SRX\s*\d+)\s+wireless headset is\s+(connected|disconnected),?\s*(?:ID\s*=\s*([\w]+))?",
    re.I,
)

# ── Voice / recognition extractors ──────────────────────────────────────────

_RE_RECOGNIZED_WORD = re.compile(
    r"Received new recognized word:\s*(.+)", re.I
)
_RE_GWS_EXECUTE_STATE = re.compile(
    r"GWS:\s*ExecuteState\s*->\s*Current State Machine\s+(\S+),\s*Current State:\s*(\S+)\s+Trigger:\s*(\S+)",
    re.I,
)
_RE_GWS_TRANSITION = re.compile(
    r"GWS:\s*Transition Executed\s*->\s*Current State Machine\s+(\S+),\s*Current State:\s*(\S+)",
    re.I,
)
_RE_DIALOG_ENTER = re.compile(
    r'Entering:\s*<Node \("([^"]+)"\)>\s*of dialog:\s*.*?\("([^"]+)"\)',
    re.I,
)
_RE_RECOGNIZER_METHOD = re.compile(r"^[<>]\s+RecognizerServiceImpl::([A-Za-z0-9_]+)\(\)", re.I)
_RE_REX_EVENT = re.compile(r"^handling REX event:\s*([A-Z0-9_]+)", re.I)
_RE_VOICE_ARTISAN = re.compile(r"^(?:[<>]\s+)?VoiceArtisanTask::([A-Za-z0-9_]+)(?:\(\)|\s+.*)?$", re.I)
_RE_RECOG_GRAMMAR = re.compile(r"^Recog grammar for Dialog\s+.+", re.I)
_RE_RECOGNIZER_STATUS = re.compile(r"^(Starting recognizer|Started recognizer|Stopping recognizer)\b", re.I)
_RE_UTTERANCE_STATE = re.compile(
    r"^(Using start-utterance grammar node|Resetting back to pre-content-word|Saw first content word of utterance)",
    re.I,
)
_RE_SRCOMM_COMMAND = re.compile(r"^SRCOMMWriter Sending command:\s*([^#]+)#:\s*(\d+)", re.I)
_RE_DIALOG_LIFECYCLE = re.compile(r"^(launch_dialog:\s*(begin|end)|Setting up transition to done state\.)", re.I)
_RE_RECOGNIZER_STATE = re.compile(r"^(About to use grammar; recognizer not running\..*|VKillSpeech called with killType\s+\d+)", re.I)
_RE_DISPLAY_MESSAGE = re.compile(r"^\[DisplayMessageBrowserQueue\]\s*Message\s*=\s*(.+?)\s+type\s*=\s*(\d+)", re.I)
_RE_TTS_PROXY = re.compile(r"^[<>]\s+LanguageTtsServiceImplProxy::([A-Za-z0-9_]+)\(\)", re.I)
_RE_REQUESTING_EOS = re.compile(r"^Requesting EOS$", re.I)

# ── Pass-3 additional speech patterns ────────────────────────────────────────

_RE_VNOTIFY_EOS = re.compile(r"^VNotifyEndOfSpeech called$", re.I)
_RE_NTOPP = re.compile(r"^NTOPP:\s*\d+->\d+", re.I)
_RE_PMS_SPEAK_EVENT = re.compile(r"^PMS_SPEAK_", re.I)
_RE_FORCING_RECOGNIZER = re.compile(r"^Forcing recognizer to start at next utterance$", re.I)
_RE_EOS_EVENT = re.compile(r"^EOS Event Generated @", re.I)
_RE_INIT_FOR_UTT = re.compile(r"^InitForUtt:\s*Refreshing grammar$", re.I)
_RE_IGNORING_RECOGNITION = re.compile(r"^Ignoring recognition\s*:", re.I)
_RE_SPEAKING_PROMPT = re.compile(r"^(?:Speaking:\s*>|VSpeakTxt called with\s*>|Done Speaking:\s*\*\*|speaking prompt\s*')", re.I)
_RE_WORD_ALREADY_EXISTS = re.compile(r'^The word ".*" already exists$', re.I)
_RE_ADAPT_SUBMIT = re.compile(r"^ADAPT:submit:", re.I)
_RE_AUDIO_GAIN = re.compile(r"^Primary Gain\s*=\s*\d+\s+Environment Gain\s*=\s*\d+", re.I)
_RE_MUTE_STATUS = re.compile(r"^(?:Got a mute status response|\(Flip-to-Mute\))", re.I)
_RE_DIGITS_PROMPT_VOCAB = re.compile(r"^DIGITS_PROMPT\s*-\s*Additional Vocabulary", re.I)
_RE_DELAY_DIGITS = re.compile(r"^Delay,\s*\d+,\s*Digits,", re.I)
_RE_UPDATING_HINT = re.compile(r"^Updating hint at Node", re.I)

# ── Pass-3 feature licensing patterns ────────────────────────────────────────

_RE_LICENSE_CHECK = re.compile(
    r"(?:isFeatureLicensed|FeatureLicensingServiceImpl|\[FeatureLicensingServiceImpl\])", re.I
)

# ── Pass-3 scanner / BLE lifecycle (extended) ────────────────────────────────

_RE_SCANNER_LIFECYCLE_EXT = re.compile(
    r"^(?:Disabling all scanners|Enabling all scanners|"
    r"BLEScannerServiceV1Impl::|Processing (?:Stop )?Scan Request|"
    r"Stopping scan|Turning [Ss]canner (?:[Oo]n|[Oo]ff)|"
    r"Scanner (?:Now On|Event Listener Successfully (?:Un)?[Rr]egistered)|"
    r"Serial Scanner Event Listener Successfully (?:Un)?[Rr]egistered|"
    r"BLE Scanner Event Listener Successfully (?:Un)?[Rr]egistered|"
    r"[Uu]nregistering scanner listener|[Rr]egistering scanner listener|"
    r"triggerScanner is supported|"
    r"setScanCallback (?:entered|has updated))",
    re.I,
)

# ── Pass-3 dialog / GWS workflow patterns ────────────────────────────────────

_RE_ENTERING_DIALOG = re.compile(r"^Entering Dialog\s+\S+\s+\(\"([^\"]+)\"\)", re.I)
_RE_EXITING_DIALOG = re.compile(r"^Exiting Dialog\s+\S+\s+\(\"([^\"]+)\"\)", re.I)
_RE_DIALOG_EXIT_NO_LINKS = re.compile(r"^Dialog\s+(\S+)\s+exiting\s+\(no more links\)\.", re.I)
_RE_TRANSITIONING_LINK = re.compile(r"^Transitioning through Link\s+(\S+)", re.I)
_RE_GWS_MESSAGE_BODY = re.compile(r'^GWS:\s*Message Body Received:', re.I)

# ── Pass-3 battery (negative runtime and compact format) ─────────────────────

_RE_BATTERY_RUNTIME_NEGATIVE = re.compile(
    r"Battery runtime(?: remaining:)?\s*(-?\d+)\s*minutes", re.I
)
_RE_BATTERY_COMPACT = re.compile(
    r"^Battery\s+([\d.]+)mV,\s*([-\d.]+)mA\s+\(([-\d.]+)\s*cumulative\s*mAh\),\s*([-\d.]+)C$",
    re.I,
)

# ── Pass-3 power management ─────────────────────────────────────────────────

_RE_POWER_MGMT = re.compile(r"^VocollectPowerMgmtService\s*:", re.I)

# ── Pass-3 radio / device info ──────────────────────────────────────────────

_RE_TIPM_REPORT = re.compile(r"^TIPM reporting\s+", re.I)
_RE_RADIO_INFO = re.compile(r"^(?:Radio Type|Radio Driver Version|Hardware \(MAC\) Address|Hardware Type)\s*[=:]", re.I)
_RE_DEVICE_META = re.compile(
    r"^(?:IP Address:|Terminal Platform Version|Code Version|Task Name|TIMESTAMP\s*-)", re.I
)

# ── Pass-3 socket / connection errors ────────────────────────────────────────

_RE_SOCKET_ERROR = re.compile(
    r"(?:Error shutting down the (?:receive|send) side of the stream socket|"
    r"Receiving socket error:|"
    r"\[VCMainThread\]\s*(?:Cleaning up|Done cleaning up) failed message|"
    r"socket closed successfully)",
    re.I,
)

# ── Pass-3 Bluetooth lifecycle ───────────────────────────────────────────────

_RE_BLUETOOTH_LIFECYCLE = re.compile(
    r"(?:^Bluetooth Connect:|"
    r"^[<>]?\s*BlueZ(?:BtConnectionThread|StackMgr)::|"
    r"^\(RECONNECTDBG\)BlueZ|"
    r"^notifyListeners:|"
    r"^Created initiator socket|"
    r"^m_connectionSocket created|"
    r"^Using a Bluetooth port of|"
    r"^Unable to retrieve BT pairing source|"
    r"^Headset ID is|"
    r"^Headset parameters haven't changed|"
    r"virtual bool BT::Bluetooth)",
    re.I,
)

# ── Pass-3 charger detection ────────────────────────────────────────────────

_RE_CHARGER_DETECT = re.compile(r"^EVDETCT:\s*ADC Level:\s*([\d.]+)v,\s*IN CHARGER", re.I)

# ── Pass-3 headset / SRX link quality ───────────────────────────────────────

_RE_SRX_LINK_STATUS = re.compile(
    r"^SRX link status\s*\|\s*quality low:\s*(\d+)\s+quality high:\s*(\d+)\s+quality avg:\s*(\d+)\s+"
    r"RSSI low:\s*(-?\d+)\s+RSSI high:\s*(-?\d+)\s+RSSI avg:\s*(-?\d+)",
    re.I,
)

# ── Pass-3 sensor data processing ───────────────────────────────────────────

_RE_SENSOR_PROCESSING = re.compile(
    r"(?:^(?:[<>]\s*)?::(?:notify|ProcessSensorData|processSensorData|publishSensorData)|"
    r"^Processing sensor data for:|"
    r"^onJsonPacket$|^Event data$|"
    r"^Nobody registered!$|"
    r"^notify : SensorEvent|"
    r"^Consumer: (?:DCM|LogFile) Sensor:)",
    re.I,
)

# ── Pass-3 content provider ─────────────────────────────────────────────────

_RE_CONTENT_PROVIDER = re.compile(r"^ContentProvider extracted a request to", re.I)

# ── Pass-3b: Voice prompt text (##...## or ##...##;pp), SURVEY roam, etc. ────

_RE_GWS_PROMPT_TEXT = re.compile(r"^##.+##(?:;pp)?$", re.I)
_RE_GWS_DELAY_RECORD = re.compile(r"^Delay,\d+,", re.I)
_RE_SURVEY_ROAM = re.compile(r"^SURVEY:\s*Roamed from AP:", re.I)
_RE_HEADSET_RUNTIME = re.compile(
    r"^Received runtime info from the headset:", re.I
)
_RE_DIALOG_AUTO_OPERATOR = re.compile(r"^DIALOG:\s*Auto Operator Loading", re.I)
_RE_SRCOMM_STATUS_QUERY = re.compile(r"^Submitting periodic (?:Titan/?SRCOMM|Titan|SRCOMM) status query", re.I)
_RE_INIT_FOR_RECOG = re.compile(r"^InitForRecog:\s*Refreshing grammar", re.I)
_RE_MIC_BOOM_FLIP = re.compile(r"^(?:Mic boom flipped|SRCOMM VoiceArtisanTask::muteRecognitions)", re.I)
_RE_VOCAB_ADDITIONAL = re.compile(
    r"^(?:READY_PROMPT|DIGITS_PROMPT)\s*[-:]", re.I
)
_RE_PMS_RECEIVE = re.compile(r"^VoiceClientEngine:\s*(?:PMS receive|Getting PMS message)", re.I)
_RE_INPROCESS_MODULE = re.compile(r"^[<>]?\s*InProcessModuleProxy::", re.I)
_RE_MID_UTTERANCE_GRAMMAR = re.compile(r"^Using mid-utterance grammar node", re.I)

# ── Pass-3b: Remaining smaller patterns ──────────────────────────────────────

_RE_SCANNER_STATE_CHANGE = re.compile(r"^State change req, but no change in reader status:", re.I)
_RE_BT_STACK_API = re.compile(
    r"^(?:BluetoothStackAPIVocPlatAPIImpl::|"
    r"connect: SRX headset pairing not enabled|"
    r"Disconnected state failed to initiate comm channel)",
    re.I,
)
_RE_EVENT_OPERATIONS = re.compile(r"^EVENT:\s*numOperationsInProgress\s+(?:in|de)cremented", re.I)
_RE_GUIDEDWORK = re.compile(r"^GUIDEDWORK:", re.I)
_RE_INACTIVITY_POWER = re.compile(r"^InactivityPowerOffInhibitor", re.I)
_RE_RAM_FILESYSTEM = re.compile(r"^RAM \(file system\):", re.I)
_RE_WORD_DISABLED = re.compile(r'^The word ".+" is disabled', re.I)
_RE_GRAMMAR_ID = re.compile(r"^Grammar ID-->", re.I)
_RE_RECOGNIZER_CALLBACK = re.compile(r"^[<>]\s*RecognizerServiceImpl::", re.I)

# ── Pass-3c: Broad catch-all patterns for remaining long tail ────────────────

_RE_EVDETCT_BATTERY = re.compile(r"^EVDETCT:\s*(?:ADC|SRX) Level:", re.I)
_RE_HEADSET_MISC = re.compile(
    r"(?:^Sending feature control to headset|"
    r"^TitanAudioInterface::|"
    r"^NfcTitanPairingMgr|"
    r"^Setting SRX sidetone level|"
    r"^SRX:\s*MCU ticks|"
    r"^Writing SRX PS key|"
    r"^Unable to retrieve headset ID|"
    r"^Checking for new headband connection|"
    r"^Received (?:audio|runtime) info from the headset)",
    re.I,
)
_RE_SPEECH_MISC = re.compile(
    r"(?:^Vocabulary word disabled|"
    r"^Grammar (?:creation complete|ID-->)|"
    r"^About to build grammar|"
    r"^Reject due to length too|"
    r"^Recognition before end of Priority Prompt|"
    r"^The word \".+\" is disabled)",
    re.I,
)
_RE_SYSTEM_MISC = re.compile(
    r"(?:^EVENT_CONTROL\s*--|"
    r"^EVENT:\s*(?:GREEN_FLASH|RED_FLASH|numOperations)|"
    r"^SYSTEM ERROR|"
    r"^IndicatorService_SetLedMode|"
    r"^InactivityPowerOffInhibitor|"
    r"^COMM:\s*COMM_Check|"
    r"^sensor_data_callback|"
    r"^Successfully made device (?:not )?discoverable|"
    r"^CCMap virt:)",
    re.I,
)
_RE_SCANNER_MISC = re.compile(
    r"^No scanner is configured", re.I
)

# ── Pass-3c: Audio frontend and remaining long-tail ──────────────────────────

_RE_AUDIO_FRONTEND = re.compile(
    r"(?:^FRONTEND:\s*(?:Starting|Stopping|resetting)|"
    r"^TIPM_Audio|"
    r"^Bluestreak input|"
    r"^Raw [Aa]udio|^Encoded input|"
    r"^No change in supervisor audio mode|"
    r"^Setting audio loopback delay|"
    r"^SRX2?\s*(?:MCU ticks|:))",
    re.I,
)
_RE_REMAINING_CATCH_ALL = re.compile(
    r"(?:^VC:\s*Checking for new headset|"
    r"^Got RUN_PAUSE event|"
    r"^FILESYS:|"
    r"^Trying to register Recognizer service callback|"
    r"^EVENT_DETECT_batteryCallBack|"
    r"^EVENT:\s*ECS\s*-|"
    r"^Phoneme stat|"
    r"^> ::EventHub::|< ::EventHub::)",
    re.I,
)

# ── Pass-4: Final long-tail patterns (remaining 0.99%) ──────────────────────

# TIPM extended (port config, enable state, disabling, training PMS)
_RE_TIPM_EXTENDED = re.compile(
    r"(?:^TIPM_(?:Update|Configure|Audio)|"
    r"^TIPM disabling|"
    r"^TIPM:\s*Couldn)",
    re.I,
)

# VC state machine transitions
_RE_VC_STATE = re.compile(
    r"(?:^(?:Entering|Leaving) VC state:|"
    r"^Got new VoiceClient state:|"
    r"^Adding static environment key/value pair)",
    re.I,
)

# Button/keypress events
_RE_BUTTON_KEYPRESS = re.compile(
    r"(?:^Toggle Run/Pause|"
    r"^Got a play/pause (?:down|up) keypress|"
    r"^(?:pressed|released) play|"
    r"^EVENT -- Yellow button pressed)",
    re.I,
)

# Audio path management
_RE_AUDIO_PATH = re.compile(
    r"(?:^AudioPathController:|"
    r"^AudioPreProcessor::reset|"
    r"^(?:Resuming|Suspending) audio output|"
    r"^Output Audio\s*:\s*Set Volume|"
    r"^OSIL_AnalogAudioInputStream::|"
    r"^configureAudioOutput|"
    r"^SYSAUDIO_getSpeechOutDelay|"
    r"^CORE LIB:\s*speech delay set)",
    re.I,
)

# System lifecycle / power events
_RE_SYSTEM_LIFECYCLE = re.compile(
    r"(?:^COMM got EVENT GOING TERM|"
    r"^EVENT -- (?:Going To TermSleep|Turning On)|"
    r"^Pallet Truck Control:|"
    r"^Paired thru NFC|"
    r"^No EAP restricted network credentials|"
    r"^Listening for new connections on port|"
    r"^WebServerProxyServiceImpl::|"
    r"^Ignoring runner task package|"
    r"^Attempting to register keypad device|"
    r"^Time:\s*[\d:]+\s*on last)",
    re.I,
)

# Extended recognizer patterns
_RE_RECOGNIZER_EXTENDED = re.compile(
    r"(?:^(?:Inactivating|Restarting) (?:recognizer|Dialog)|"
    r"^[<>]\s*RecognizeServiceImpl::inactivateRecognition|"
    r"^GETNOISE\s*-|"
    r"^RRREPLAY MARKER:|"
    r"^USERDATA_mainThreadMainLoop:\s*RECOG_EVENT|"
    r"^TSND_EV_GOT_ADAPT_NOT_BUSY|"
    r"^Could not update hint|"
    r"^Creating recog grammar for Dialog|"
    r"^TTS speech aborted|"
    r"^SPEAK Volume changed)",
    re.I,
)

# SRX headset sidetone and audio interface
_RE_SRX_AUDIO = re.compile(
    r"(?:^SRX (?:Sidetone|Audio Interface)|"
    r"^Setting sidetone to:|"
    r"^Mic monitor control not applicable|"
    r"^Checking for new headset connection for voice load|"
    r"^lookupService\(\s*PlatformServices::Audio::MicMonitor)",
    re.I,
)

# Audio interface (AI) change notifications
_RE_AI_CHANGE = re.compile(
    r"(?:^[<>]\s*Recorder::onAiChange|"
    r"^FRONTEND:\s*Frontend has received an AI change|"
    r"^\[VoiceClientUtilities\]\s*Error calling VOC_HEADSETAPI|"
    r"^Received notification of AI change|"
    r"^Activating AI type)",
    re.I,
)

# VoiceConsole / GuidedWork startup
_RE_VOICECONSOLE_STARTUP = re.compile(
    r"(?:^:\s*Sending command to VoiceConsole|"
    r"^Executable Path:|"
    r"^GuidedWorkAppName:|"
    r"^DOTNET_ROOT:)",
    re.I,
)

# RSA (Recognition/Speech Analysis) telemetry
_RE_RSA_TELEMETRY = re.compile(r"^RSA:\s*[fi]TS\s+a=", re.I)

# Config item discovery
_RE_CONFIG_ITEM_DISCOVERY = re.compile(r"^Found new config item\s", re.I)

# Event sensor extended
_RE_EVENT_SENSOR_EXTENDED = re.compile(
    r"(?:^[<>]\s*EventStateChangeSensor::|"
    r"^SensorBrokerServiceV1Impl::|"
    r"^registerListener\s+listener\s+registered|"
    r"^Adding listener to list:|"
    r"^WaitForEventTimer::)",
    re.I,
)

# Bluetooth extended (BlueZ constructor/disconnect, BT discoverable)
_RE_BLUETOOTH_EXTENDED = re.compile(
    r"(?:^BlueZBluetoothCommChannelV2\s+Constructor|"
    r"^Auto setting BT discoverable|"
    r"^[<>]\s*BlueZBluetoothCommChannelV2::disconnect)",
    re.I,
)

# System events extended (GREEN_ON, mergeItemWithMasterQueue, EVENT_DETECT_titan, etc.)
_RE_SYSTEM_EVENTS_EXTENDED = re.compile(
    r"(?:^EVENT:\s*GREEN_ON|"
    r"^\[mergeItemWithMasterQueue\]|"
    r"^EVENT_DETECT_titanBatteryCallBack|"
    r"^[<>]\s*::initialize$|"
    r"^[<>]\s*registerListener$)",
    re.I,
)

# ── Pass-4b: Second wave long-tail patterns ──────────────────────────────────

# TIPM volume/set and extended audio events
_RE_TIPM_SET = re.compile(
    r"(?:^TIPM\s+set\s|"
    r"^TmanDll:\s*received\s+TIPM_AUDIO)",
    re.I,
)

# Beep/speaker events
_RE_BEEP_EVENTS = re.compile(
    r"(?:^(?:start|stop)(?:System|Periodic)(?:Busy)?Beep|"
    r"^Beep:\s*freq=|"
    r"^SPK_VBeep\s+called)",
    re.I,
)

# Voice adaptation / training pipeline (ADAPT, TSND, TRAIN HELPER)
_RE_VOICE_ADAPT_TRAIN = re.compile(
    r"(?:^ADAPT:\s|"
    r"^TSND(?:_EV_GOT|_reportTrain|:\s*Sending)|"
    r"^Trying to add word|"
    r"^Ignoring store-oper-template-complete|"
    r"^TRAIN HELPER:|"
    r"^Reading embedded prompt file|"
    r"^Will Add\s+\d+\s+embedded strings)",
    re.I,
)

# Platform service lookup/register
_RE_PLATFORM_SERVICES = re.compile(
    r"(?:^lookupService\(\s*PlatformServices::|"
    r"^registerService:\s*PlatformServices::)",
    re.I,
)

# Dialog notifications and state flags
_RE_DIALOG_NOTIFY = re.compile(
    r"(?:^DIALOG:\s*Notifying Console|"
    r"^Setting Dialog-Processing-Action-Item|"
    r"^Setting\s+\d+\s+to\s+\d+\s+states)",
    re.I,
)

# Charger/titan status
_RE_CHARGER_STATUS = re.compile(
    r"(?:^Unable to determine if the configuration data is valid.*EasyCharger|"
    r"^Ignoring titan status change)",
    re.I,
)

# Thread priority changes
_RE_THREAD_PRIORITY = re.compile(r"^Thread:\s*<SRCOMM\s", re.I)

# Supervisor audio config
_RE_SUPERVISOR_AUDIO = re.compile(r"^Attempting to change Supervisor Audio", re.I)

# Bluetooth extended config
_RE_BT_CONFIG = re.compile(
    r"(?:^Changing auto connect status|"
    r"^[<>]\s*BlueZBluetoothCommChannelV2::setConfig|"
    r"^Config item:\s*Bt_Address)",
    re.I,
)

# GUIDEDWORK extended (space before colon)
_RE_GUIDEDWORK_STARTUP = re.compile(r"^GUIDEDWORK\s+STARTUP:", re.I)

# Time/timezone events
_RE_TIME_ZONE = re.compile(r"^Time:\s*[\d:]+\s*on\s+last", re.I)

# ── Pass-4c: Third wave long-tail patterns ───────────────────────────────────

# Config items (Bt_ and other config key:value entries)
_RE_CONFIG_ITEM_KV = re.compile(
    r"(?:^Config item:\s*\w+|"
    r"^Unknown key:\s*\w+)",
    re.I,
)

# Sensor registration (::addSensor)
_RE_ADD_SENSOR = re.compile(r"^::addSensor\s*:", re.I)

# TAI / headset connection transitions
_RE_TAI_CONNECT = re.compile(
    r"(?:^TAI run\(\)\s*Transitioning|"
    r"^connect:\s*About to connect to headset)",
    re.I,
)

# Timezone/DST metadata
_RE_DST_METADATA = re.compile(
    r"(?:^Standard:\s*Unknown|"
    r"^DaylightSavings:\s*Unknown|"
    r"^Bias:\s*-?\d+)",
    re.I,
)

# Audio capture / volume service
_RE_AUDIO_CAPTURE = re.compile(
    r"(?:^AudioInCaptureThread::|"
    r"^Mixed volume service)",
    re.I,
)

# TIPM module directory path
_RE_TIPM_DIR = re.compile(r"^TIPM returning module dir", re.I)

# Thread start / priority
_RE_THREAD_START = re.compile(r"^Thread:\s*<(?:VC Notification|SRCOMM)", re.I)

# Operator check / load
_RE_OPER_LIFECYCLE = re.compile(
    r"(?:^OPERCHK:|"
    r"^OPERLOAD:|"
    r"^\(CRASHDBG\)\s*VSetOperLoaded|"
    r"^SendTerminalPropertiesCommand::|"
    r"^VoiceModule cache free)",
    re.I,
)

# Extended sensor refresh
_RE_SENSOR_REFRESH = re.compile(r"^[<>]\s*::onSensorRefresh", re.I)

# ── Pass-4d: Final sweep for remaining tiny groups ───────────────────────────

# SRCOMM disconnect
_RE_SRCOMM_DISCONNECT = re.compile(
    r"(?:^(?:Attempting to|Successfully) disconnect(?:ed)? from SRCOMM|"
    r"^Reporting (?:Min|Max) Sidetone Gain|"
    r"^Erasing listener:|"
    r"^DIALOG:\s*SRX\s+(?:Pairing|Confirmation)\s+set)",
    re.I,
)

# NFC / maintenance mode / charger cradle
_RE_MAINTENANCE_MODE = re.compile(
    r"(?:^(?:Registering|Unregistering) NFC Titan|"
    r"^First Nfc listener|"
    r"^Successfully started NFC|"
    r"^Received request to enter maintenance|"
    r"^TIPM\s+Resetting Bluetooth|"
    r"^TIPM_ResetBluetoothConfig|"
    r"^Maintenance mode activation|"
    r"^Forcing Transition to Charging State|"
    r"^EVDETCT:\s*sending CRADLED|"
    r"^Checking BT Discoverable state due to|"
    r"^[<>]\s*::onActivateMaintMode|"
    r"^Setting initial state to maintenance|"
    r"^setEventCallback entered)",
    re.I,
)

# GUIDEDWORK main loop / speak timing
_RE_GUIDEDWORK_MAIN = re.compile(
    r"(?:^GUIDEDWORKMAIN:|"
    r"^SPEAK:\s*Waiting for end of speak|"
    r"^\[VCSendLogData\]|"
    r"^TIMESTAMP:\s*Unable to read)",
    re.I,
)

# ── Pass-5: Perfection sweep — remaining 0.87% ──────────────────────────────

# ASR (Automatic Speech Recognition) output results — lines starting with ^^
# These are the raw recognised-word / token sequences from the speech engine.
_RE_ASR_RESULT = re.compile(r"^\^\^")

# Thread lifecycle: Thread: <Name> ID:, UserThread::, threadProc DEBUG
_RE_THREAD_LIFECYCLE = re.compile(
    r"(?:^Thread:\s*<(?!SRCOMM|VC Notification)|"
    r"^UserThread::|"
    r"^threadProc\s)",
    re.I,
)

# Module initialisation / teardown
_RE_MODULE_INIT = re.compile(
    r"(?:^Initializing\s+'|"
    r"^Finished init of:\s+'|"
    r"^>\s*[A-Za-z]+Module::|"
    r"^<\s*[A-Za-z]+Module::)",
    re.I,
)

# SRCOMM reader/writer lifecycle (not already caught)
_RE_SRCOMM_LIFECYCLE = re.compile(
    r"(?:^SRCOMM\s+(?:Reader|Writer|class)|"
    r"^Hello from SRCOMM|"
    r"^Entered SRCOMM)",
    re.I,
)

# SRX2 headset binary telemetry
_RE_SRX2_TELEMETRY = re.compile(
    r"^SRX2\s+(?:BN|BA|BX|DSP|AG|disconnect|just reset|power down|HW event)\b",
    re.I,
)

# Service registry operations (Looking up / registering services)
_RE_SERVICE_REGISTRY = re.compile(
    r"(?:^Looking up[:\s]|"
    r"^ServiceSelector\s*-\s*|"
    r"^obtaining service directory)",
    re.I,
)

# Control function enable/disable
_RE_CONTROL_FUNCTION = re.compile(r'^control function\s+"', re.I)

# TTS / speech rate / pitch / volume proxy
_RE_TTS_PROXY = re.compile(
    r"(?:^TTS-Voice|"
    r"^TtsProxy\s|"
    r"^Setting TTS\s|"
    r"^Resetting TTS\s|"
    r"^Setting volume\s|"
    r"^SPEAK\s+(?:SpeechRate|Pitch)\s)",
    re.I,
)

# [execute] GWS action items
_RE_EXECUTE_CMD = re.compile(r"^\[execute\]", re.I)

# Connection events (headset, Titan, TAI, state transitions)
_RE_CONNECT_LIFECYCLE = re.compile(
    r"(?:^Connect:\s*name\s*=|"
    r"^completeConnect\s|"
    r"^Connected to headset|"
    r"^Titan got\s|"
    r"^Connected state saw|"
    r"^disconnecting the TAI|"
    r"^No need to disconnect|"
    r"^Trying to (?:connect|kill)|"
    r"^TAI detected comm)",
    re.I,
)

# Sensor configuration (continuous + on-refresh)
_RE_SENSOR_CONFIG = re.compile(
    r"(?:^::getContinuousSensor|"
    r"^::getOnRefreshSensor|"
    r"^::intitialize\s*TalkmanApp|"
    r"^::registerForA700x|"
    r"^::registerConsumer\b|"
    r"^DeviceDrop::|"
    r"^SensorBrokerModule::)",
    re.I,
)

# Sensor event listener registration
_RE_SENSOR_LISTENER_REG = re.compile(
    r"(?:^EVENT_registerListener|"
    r"^COMMAPI_registerListener|"
    r"^BSD_registerListener|"
    r"^DIALOGUTILS_registerListener|"
    r"^registerListener\s*:|"
    r"^>\s*registerFor)",
    re.I,
)

# Headset hardware / SRX config / battery / audio card
_RE_HEADSET_HW = re.compile(
    r"(?:^Audio Card\s|"
    r"^Received static info\s|"
    r"^Battery pack revision|"
    r"^Setting SRX\s|"
    r"^Setting headset\s|"
    r"^Using SRX\s|"
    r"^Enabling MICOS|"
    r"^Got headset version|"
    r"^Turning headset|"
    r"^SRCOMM returned\s|"
    r"^SRCOMMReader receive\s|"
    r"^Set SRX output|"
    r"^SRX pairing)",
    re.I,
)

# Audio interface switching (AI switching)
_RE_AI_SWITCHING = re.compile(
    r"(?:^Switching AI\s|"
    r"^disabling previously active|"
    r"^Activating services of|"
    r"^notifying users the active AI|"
    r"^(?:activating|deactivating) service group)",
    re.I,
)

# Audio recorder / analog input
_RE_RECORDER_AUDIO = re.compile(
    r"(?:^>\s*Recorder::|"
    r"^<\s*Recorder::|"
    r"^AnalogInputAudioStream::|"
    r"^Starting input\s|"
    r"^Stopping audio\s)",
    re.I,
)

# VCMainThread events
_RE_VC_MAIN_THREAD = re.compile(r"^\[?VCMainThread\]?\s", re.I)

# AP monitor events
_RE_AP_MONITOR = re.compile(r"^AP MON:", re.I)

# Config / setup events (barcode, EMB, FIL, SCGI, CORE LIB, etc.)
_RE_CONFIG_SETUP = re.compile(
    r"(?:^Setting scan|"
    r"^BarcodeMax|^BarcodeBuffer|^BarcodeClean|^BarcodeVerbose|^BarcodeCharset|"
    r"^Setting scanner|"
    r"^Found\s+\d+\s+(?:EMB|FIL)|"
    r"^CORE LIB:|"
    r"^Logging of received|"
    r"^Use SCGI|"
    r"^using system\s)",
    re.I,
)

# Voice training / RECOG / systring
_RE_VOICE_TRAINING = re.compile(
    r"(?:^RECOG:\s|"
    r"^TRAIN,\s|"
    r"^Not reading embedded|"
    r"^Reading embedded|"
    r"^Loading systring|"
    r"^Requested\s+\d+\s+bytes\s+from\s+the\s+systring|"
    r"^Current locale for|"
    r"^Loaded\s+\d+\s+systrings)",
    re.I,
)

# Noise sample thread lifecycle
_RE_NOISE_SAMPLE = re.compile(
    r"(?:^Noise sample\s|"
    r"^process exiting)",
    re.I,
)

# Minus button events (physical button)
_RE_MINUS_BUTTON = re.compile(
    r"(?:^Got a minus\s|"
    r"^pressed minus|"
    r"^released minus|"
    r"^EVENT -- Minus\s)",
    re.I,
)

# Sidetone events
_RE_SIDETONE = re.compile(
    r"(?:^Sidetone (?:Enabled|disabled|Disabled)|"
    r"^Set sidetone gain)",
    re.I,
)

# TIPM audio / headset notifications via TIPM
_RE_TIPM_AUDIO_HEADSET = re.compile(
    r"(?:^AudioMsgHandlerTIPM:|"
    r"^TIPM (?:detects|received)\s+headset|"
    r"^TmanDll:\s*current\s|"
    r"^TalkmanInProcessModule\s+got)",
    re.I,
)

# Power status notifications
_RE_POWER_NOTIFY = re.compile(r"^Notifying power status", re.I)

# misc system messages (Unable, Failed, config changed, etc.)
_RE_MISC_SYSTEM = re.compile(
    r"(?:^Unable to (?:find value|tell if|enable)|"
    r"^Failed to get current RSSI|"
    r"^config changed in|"
    r"^Successfully revoked link|"
    r"^No headset search in progress|"
    r"^Successfully stopped (?:titan|NFC)|"
    r"^Last Nfc listener|"
    r"^Successfully started NFC|"
    r"^Erasing listener|"
    r"^Trying to connect state)",
    re.I,
)

# Key lookup / module lifecycle verbs
_RE_VERB_LIFECYCLE = re.compile(
    r"(?:^Running\s|^Run\s|"
    r"^Added\s|^Registering\s|^Registered\s|"
    r"^Calling\s|^Called\s|"
    r"^Asked\s|"
    r"^Notifying\s|"
    r"^Enabling\s|"
    r"^Currently,\s)",
    re.I,
)

# RingBuffer, PSUtils, SensorBroker init lifecycle
_RE_INIT_LIFECYCLE = re.compile(
    r"(?:^<\s*RingBufferModule::|"
    r"^>\s*PSUtils|^<\s*PSUtils|"
    r"^Finished init of:\s|"
    r"^VOC_IND_Init|"
    r"^Inactivate Event|"
    r"^Looking up\s|"
    r"^>\s*::tasInitialize|^<\s*::tasInitialize|"
    r"^<\s*registerFor)",
    re.I,
)

# TCP / comm error signals
_RE_COMM_ERROR = re.compile(
    r"(?:^\[listenForTCP\]|"
    r"^Unknown error on send|"
    r"^Error detected:\s*SRCOMM_ERROR)",
    re.I,
)

# RSA uTS telemetry (variant of RSA: iTS already captured)
_RE_RSA_UTS = re.compile(r"^RSA:\s*uTS\b", re.I)

# VAD revision line
_RE_VAD_REVISION = re.compile(r"^\(NG_IMI_v\d", re.I)

# ── Pass-5b: Second wave — remaining 0.42% ──────────────────────────────────

# LanguageTtsServiceImplProxy method calls (> / <  entry/exit)
_RE_LANG_TTS_PROXY = re.compile(r"LanguageTtsServiceImplProxy::", re.I)

# lookupService( ...) that were NOT caught by _RE_PLATFORM_SERVICES
_RE_LOOKUP_SERVICE_EXTRA = re.compile(
    r"^lookupService\(", re.I,
)

# Startup / initialization sequence
_RE_STARTUP_SEQ = re.compile(
    r"(?:^STARTUP[_:\s]|"
    r"^\(SEC\)STARTUP_)",
    re.I,
)

# RTC clock / timezone restore
_RE_RTC_CLOCK = re.compile(r"^RTC_", re.I)

# Template send / TSND state machine
_RE_TSND_TEMPLATE = re.compile(
    r"(?:^TSND[_:\s]|"
    r"^TEMPLATE\s|"
    r"^TSND_REPORT)",
    re.I,
)

# USERDATA main thread
_RE_USERDATA = re.compile(r"^USERDATA_", re.I)

# SYSAUDIO gain / hardware
_RE_SYSAUDIO = re.compile(r"^SYSAUDIO_", re.I)

# Named pipe, Linux pipe reader, watchdog
_RE_NAMED_PIPE = re.compile(
    r"(?:^Named Pipe|"
    r"^>\s*long unsigned int Linux|"
    r"^Vocollect Application watchdog)",
    re.I,
)

# Titan comm / pairing
_RE_TITAN_COMM = re.compile(
    r"(?:^Titan (?:Created|run)|"
    r"^Comm channel has changed|"
    r"^Pairing required flag|"
    r"^Created and hooked up the Titan)",
    re.I,
)

# Serial / USB / port lifecycle
_RE_SERIAL_USB = re.compile(
    r"(?:^Created serial|"
    r"^Started serial|"
    r"^Started USB|"
    r"^usbAttached|"
    r"^Importing COMM)",
    re.I,
)

# Scripting / web server config
_RE_SCRIPTING_WEB = re.compile(
    r"(?:^Scripting\s|"
    r"^RemoteScripting\s|"
    r"^Application Name:|"
    r"^portOptions:|"
    r"^WWW root|"
    r"^Starting Mongoose)",
    re.I,
)

# BLE / BlueStreak / BtMgmt
_RE_BLE_INIT = re.compile(
    r"(?:^BtMgmtService\b|"
    r"^BlueStreakEngine\b|"
    r"^Initializing BLE|"
    r"^Creating BLE)",
    re.I,
)

# Message browser queue / terminal command queue
_RE_MESSAGE_QUEUE = re.compile(
    r"(?:^Mesage Browser|"
    r"^\[Message Browser|"
    r"^\[DisplayMessage|"
    r"^TerminalCommand|"
    r"^\[TerminalCommandRetry)",
    re.I,
)

# SOCKSEND / EAP / event signals
_RE_SOCKSEND_EAP = re.compile(
    r"(?:^SOCKSEND|"
    r"^EAPMSG|"
    r"^EVENT\s+--|"
    r"^EVENT:\s)",
    re.I,
)

# Negative battery percentage (edge case of battery parser)
_RE_BATTERY_NEGATIVE = re.compile(r"^Battery percent remaining:\s*-\d", re.I)

# ZMQ / misc system startup
_RE_ZMQ_MISC = re.compile(
    r"(?:^ZMQ version|"
    r"^Adding state change|"
    r"^Selecting\s|"
    r"^Got a CommChannel|"
    r"^Write until complete|"
    r"^PrintService:)",
    re.I,
)

# ExitDialog / dialog flow states
_RE_EXIT_DIALOG = re.compile(r"^ExitDialog\b", re.I)

# ASR engine version
_RE_ASR_ENGINE = re.compile(r"^ASR engine version", re.I)

# System assert / config read / obtaining snapshot
_RE_SYSTEM_ASSERT = re.compile(
    r"(?:^SYSTEM_Assert|"
    r"^Could not read configuration|"
    r"^Couldn't get\s|"
    r"^obtaining snapshot|"
    r"^Skipping configuration|"
    r"^System supports)",
    re.I,
)

# BSD / COMM PMS / process events
_RE_BSD_COMM = re.compile(
    r"(?:^COMM got PMS|"
    r"^BSD[_:\s]|"
    r"^processEventsUntilShutdown)",
    re.I,
)

# CAB/version metadata
_RE_CAB_VERSION = re.compile(r"Version=Unknown,Provides", re.I)

# requestTimeResponse / time sync
_RE_REQUEST_TIME = re.compile(r"requestTimeResponse|SetDateAndTime", re.I)

# VC main thread startup / transitions
_RE_VC_STARTUP = re.compile(
    r"(?:^VC:\s|"
    r"^\[VCSendLog)",
    re.I,
)

# Creating/Created objects
_RE_CREATING_OBJ = re.compile(r"^Creat(?:ing|ed)\s", re.I)

# Starting/Started threads/services
_RE_STARTING_OBJ = re.compile(r"^Start(?:ing|ed)\s", re.I)

# Stored / Fetched / Ignoring / Waiting
_RE_MISC_VERBS = re.compile(
    r"(?:^Stored\s|^Fetched\s|^Ignoring\s|^Waiting\s|"
    r"^Headset\s|^NFC\s|^No\s+\w+\s+in\s|"
    r"^Get\s+\w+\s|^SRX V1\s)",
    re.I,
)

# Received / Error / Err
_RE_RECEIVED_ERR = re.compile(
    r"(?:^Received\s|"
    r"^Error\b|^Err\b|"
    r"^Unable to\s|"
    r"^VOCOLLECT\b|"
    r"^EVDETCT\b|"
    r"^Task\s)",
    re.I,
)

# Signal strength thread
_RE_SIGNAL_THREAD = re.compile(r"^Starting signalStrength", re.I)

# SRX headset recognition delay
_RE_RECOG_DELAY = re.compile(r"^Setting recognition delay", re.I)

# Attempting (various)
_RE_ATTEMPTING = re.compile(r"^Attempting\s", re.I)

# --- Pass-5 Wave 3: final 403 events ---

# Maintenance mode activation/deactivation
_RE_MAINT_MODE = re.compile(
    r"(?:::onDeactivateMaintMode|"
    r"^Maintenance mode\s)",
    re.I,
)

# Sensor producer continuous read thread
_RE_SENSOR_READ_THREAD = re.compile(r"::continuousSensorReadThread\[", re.I)

# HTTP resource manager requests
_RE_HTTP_RESOURCE_MGR = re.compile(
    r"(?:^\[HttpResourceMgrRequest|"
    r"^\[Get\]\s)",
    re.I,
)

# VSpeak service impl
_RE_VSPEAK_SVC = re.compile(r"^VSpeakSvcImpl::", re.I)

# File sent to Voice Console
_RE_FILE_SENT_VC = re.compile(r"^File\s+\S+\s+was successfully sent to Voice Console", re.I)

# Operator key press / load / config
_RE_OPERATOR_ACTIONS = re.compile(
    r"(?:^(?:Got a )?operator\s(?:down|up|load)|"
    r"^pressed operator|"
    r"^released operator|"
    r"^Operator Load|"
    r"^setOperatorLoadCallback\b|"
    r"^Invoking operator load callback|"
    r"^Just sent operator loaded|"
    r"^:\s+Sending operator configuration|"
    r"^Got store-oper-config-complete|"
    r"^Setting initial state\b|"
    r"^Setting mixed volume\b|"
    r"^Status for Load Task\b)",
    re.I,
)

# BT pairing / NFC tag read
_RE_BT_NFC_PAIRING = re.compile(
    r"(?:^BT pairing tag parsed|"
    r"^Cleared headband ID|"
    r"^Revoking link key|"
    r"^Persisted Headset ID|"
    r"^Platform notified us of a tag|"
    r"^Titan Pairing Mgr received|"
    r"^Completed callbacks for tag|"
    r"^Current reader is reading flag|"
    r"^Got a NULL NFC TAG|"
    r"^Failed to read tag NDEF)",
    re.I,
)

# Task package load/unload
_RE_TASK_PACKAGE = re.compile(
    r"(?:^(?:Un)?[Ll]oading task package|"
    r"^unloadTaskPackage:|"
    r"^TASKLOAD:|"
    r"^Finished with task load|"
    r"^Loading task package|"
    r"^Storing current task|"
    r"^ATBO(?:\s|:))",
    re.I,
)

# Template / hibernation files
_RE_TEMPLATE_HIB = re.compile(
    r"(?:^Opening TmplSend hibernation|"
    r"^Unzipping template\.zip)",
    re.I,
)

# Bluetooth manual pairing / snapshot / charger transitions
_RE_MISC_DEVICE_OPS = re.compile(
    r"(?:^Bluetooth manual pairing|"
    r"^No Snapshot/Crash dump|"
    r"^Forcing Transition to|"
    r"^Hooked up the State Service|"
    r"^##Talkman##|"
    r"^VCMS:|"
    r"^No printer name|"
    r"^Not enabling Titan|"
    r"^Variable packet size detected|"
    r"^Removing existing key/value)",
    re.I,
)

# Grammar / recognizer stop
_RE_GRAMMAR_STOP = re.compile(r"^About to use grammar", re.I)

# Sidetone extended (current reporting, TIPM exception)
_RE_SIDETONE_EXT = re.compile(
    r"(?:^Sidetone currently|"
    r"^Reporting Current Sidetone|"
    r"^TIPM_DisableSidetone exception)",
    re.I,
)

# GETNOISE / noise sample
_RE_GETNOISE = re.compile(
    r"(?:^GETNOISE:|"
    r"^GetNoise process|"
    r"^RECOG_EVENT_NOISESAMP_)",
    re.I,
)

# BLE advertise callback
_RE_BLE_CALLBACK = re.compile(r"::(?:un)?registerBLEAdvertise", re.I)

# Action item / dialog store / GuidedWork internal
_RE_ACTION_DIALOG = re.compile(
    r"(?:^Action Item sending|"
    r"^DIALOG:\s+storeTaskLoadMsgInfo|"
    r"^Stopping GuidedWork Server|"
    r"^CONFIGPARAM:)",
    re.I,
)

# Voc image callback
_RE_VOC_IMG = re.compile(r"^Voc ImgCallback", re.I)

# Stack unwinding / exception traces
_RE_STACK_TRACE = re.compile(
    r"(?:^Beginning to unwind stack|"
    r"^Traceback \(most recent|"
    r"^(?:\s+)?at\s+\S+\.\S+[\.(]|"
    r"^File\s+\".+\",\s+line\s+\d+|"
    r"^Halting execution|"
    r"^Exception:\s|"
    r"^AttributeError:|"
    r"^conditional script\b|"
    r"^\(\)$)",
    re.I,
)

# ptMultipleStateMachine state transitions
_RE_STATE_MACHINE = re.compile(r"^ptMultipleStateMachine", re.I)

# ePutPrompt / Send Successful / TAI disconnected / misc single events
_RE_MISC_FINAL = re.compile(
    r"(?:^ePutPrompt|"
    r"^Send Successful Event|"
    r"^TAI disconnected|"
    r"^First use date of|"
    r"^environment_change\.)",
    re.I,
)


def extract_system_resources(ev: LogEvent) -> bool:
    """Try to extract CPU / RAM / Flash metrics. Returns True if matched."""
    msg = ev.message

    m = _RE_CPU_USAGE.search(msg)
    if m:
        ev.component = "system"
        ev.event_type = "cpu_usage"
        return True

    m = _RE_RAM_USAGE.search(msg)
    if m:
        ev.component = "system"
        ev.event_type = "ram_usage"
        return True

    m = _RE_FLASH_USAGE.search(msg)
    if m:
        ev.component = "system"
        ev.event_type = "flash_usage"
        return True

    return False


def extract_system_diagnostics(ev: LogEvent) -> bool:
    """Try to classify repeated system transport / config messages."""
    msg = ev.message

    if _RE_CONTINUOUS_SOCKET.search(msg):
        ev.component = "system"
        ev.event_type = "system_socket_activity"
        return True

    if _RE_PMS_MESSAGE.search(msg):
        ev.component = "system"
        ev.event_type = "system_pms_message"
        return True

    if _RE_CONFIG_CHANGE.search(msg):
        ev.component = "system"
        ev.event_type = "system_config_change"
        return True

    if _RE_VC_SEND_LOG.search(msg) or _RE_VC_SEND_SUCCESS.search(msg):
        ev.component = "system"
        ev.event_type = "system_voice_console_transfer"
        return True

    if _RE_SCANNER_EVENT.search(msg):
        ev.component = "system"
        ev.event_type = "system_scanner_event"
        return True

    if _RE_BATTERY_IDENTIFIER.search(msg):
        ev.component = "system"
        ev.event_type = "system_battery_identifier"
        return True

    return False


def extract_operator(ev: LogEvent) -> bool:
    """Try to extract operator identity. Returns True if matched."""
    m = _RE_OPERATOR.search(ev.message)
    if m:
        ev.component = "system"
        ev.event_type = "operator_login"
        return True
    return False


def extract_headset(ev: LogEvent) -> bool:
    """Try to extract headset status. Returns True if matched."""
    m = _RE_HEADSET.search(ev.message)
    if m:
        ev.component = "system"
        status = m.group(2).lower()
        ev.event_type = "headset_connected" if status == "connected" else "headset_disconnected"
        ev.severity = "warning" if status == "disconnected" else "info"
        return True
    return False


def extract_voice(ev: LogEvent) -> bool:
    """Try to extract voice recognition events. Returns True if matched."""
    msg = ev.message

    m = _RE_RECOGNIZED_WORD.search(msg)
    if m:
        ev.component = "speech"
        ev.event_type = "voice_recognized_word"
        return True

    return False


def extract_gws_workflow(ev: LogEvent) -> bool:
    """Try to extract structured GWS workflow events. Returns True if matched."""
    msg = ev.message

    m = _RE_GWS_EXECUTE_STATE.search(msg)
    if m:
        ev.component = "gws"
        ev.event_type = "gws_execute_state"
        return True

    m = _RE_GWS_TRANSITION.search(msg)
    if m:
        ev.component = "gws"
        ev.event_type = "gws_transition"
        return True

    m = _RE_DIALOG_ENTER.search(msg)
    if m:
        ev.component = "gws"
        ev.event_type = "gws_dialog_enter"
        return True

    return False


def extract_speech_diagnostics(ev: LogEvent) -> bool:
    """Try to classify recognizer lifecycle and speech pipeline diagnostics."""
    msg = ev.message

    if _RE_RECOGNIZER_METHOD.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_call"
        return True

    if _RE_REX_EVENT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_rex_event"
        return True

    if _RE_VOICE_ARTISAN.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_voice_artisan"
        return True

    if _RE_RECOG_GRAMMAR.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_grammar_event"
        return True

    if _RE_RECOGNIZER_STATUS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_lifecycle"
        return True

    if _RE_UTTERANCE_STATE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_utterance_state"
        return True

    if _RE_SRCOMM_COMMAND.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_srcomm_command"
        return True

    if _RE_DIALOG_LIFECYCLE.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_dialog_lifecycle"
        return True

    if _RE_RECOGNIZER_STATE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_state"
        return True

    if _RE_DISPLAY_MESSAGE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_display_message"
        return True

    if _RE_TTS_PROXY.search(msg) or _RE_REQUESTING_EOS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_tts_event"
        return True

    return False


def extract_speech_pipeline(ev: LogEvent) -> bool:
    """Classify pass-3 speech pipeline patterns (EOS, NTOPP, PMS, prompts, etc.)."""
    msg = ev.message

    if _RE_VNOTIFY_EOS.search(msg) or _RE_EOS_EVENT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_eos_event"
        return True

    if _RE_NTOPP.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_ntopp"
        return True

    if _RE_PMS_SPEAK_EVENT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_pms_event"
        return True

    if _RE_FORCING_RECOGNIZER.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_state"
        return True

    if _RE_INIT_FOR_UTT.search(msg) or _RE_DELAY_DIGITS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_grammar_event"
        return True

    if _RE_IGNORING_RECOGNITION.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognition_ignored"
        return True

    if _RE_SPEAKING_PROMPT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_tts_event"
        return True

    if _RE_WORD_ALREADY_EXISTS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_vocab_event"
        return True

    if _RE_ADAPT_SUBMIT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_adapt_event"
        return True

    if _RE_AUDIO_GAIN.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_gain"
        return True

    if _RE_MUTE_STATUS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_mute_status"
        return True

    if _RE_DIGITS_PROMPT_VOCAB.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_vocab_config"
        return True

    if _RE_UPDATING_HINT.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_hint_update"
        return True

    return False


def extract_scanner_lifecycle(ev: LogEvent) -> bool:
    """Classify pass-3 scanner and BLE lifecycle patterns."""
    if _RE_SCANNER_LIFECYCLE_EXT.search(ev.message):
        ev.component = "scanner"
        ev.event_type = "scanner_lifecycle"
        return True
    return False


def extract_dialog_workflow(ev: LogEvent) -> bool:
    """Classify pass-3 GWS dialog enter/exit and link transitioning."""
    msg = ev.message

    m = _RE_ENTERING_DIALOG.search(msg)
    if m:
        ev.component = "gws"
        ev.event_type = "gws_dialog_enter"
        return True

    m = _RE_EXITING_DIALOG.search(msg)
    if m:
        ev.component = "gws"
        ev.event_type = "gws_dialog_exit"
        return True

    if _RE_DIALOG_EXIT_NO_LINKS.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_dialog_exit"
        return True

    if _RE_TRANSITIONING_LINK.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_link_transition"
        return True

    if _RE_GWS_MESSAGE_BODY.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_message_body"
        return True

    return False


def extract_battery_extended(ev: LogEvent) -> bool:
    """Classify pass-3 battery patterns: negative runtime and compact format."""
    msg = ev.message

    m = _RE_BATTERY_RUNTIME_NEGATIVE.search(msg)
    if m:
        ev.component = "battery"
        ev.event_type = "battery_runtime"
        ev.severity = "warning"
        ev.battery = BatteryMetrics(runtime_min=float(m.group(1)))
        return True

    m = _RE_BATTERY_COMPACT.search(msg)
    if m:
        try:
            ev.component = "battery"
            ev.event_type = "battery_compact_telemetry"
            ev.battery = BatteryMetrics(
                voltage_mv=float(m.group(1)),
                current_ma=float(m.group(2)),
                energy_consumption_mah=float(m.group(3)),
                temperature_c=float(m.group(4)),
            )
            return True
        except ValueError:
            pass

    return False


def extract_licensing(ev: LogEvent) -> bool:
    """Classify feature licensing check patterns."""
    if _RE_LICENSE_CHECK.search(ev.message):
        ev.component = "system"
        ev.event_type = "system_license_check"
        return True
    return False


def extract_power_management(ev: LogEvent) -> bool:
    """Classify power management service patterns."""
    if _RE_POWER_MGMT.search(ev.message):
        ev.component = "system"
        ev.event_type = "system_power_management"
        return True
    return False


def extract_radio_device_info(ev: LogEvent) -> bool:
    """Classify radio info, device metadata, TIPM reports."""
    msg = ev.message

    if _RE_TIPM_REPORT.search(msg):
        ev.component = "system"
        ev.event_type = "system_device_info"
        return True

    if _RE_RADIO_INFO.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_radio_info"
        return True

    if _RE_DEVICE_META.search(msg):
        ev.component = "system"
        ev.event_type = "system_device_info"
        return True

    return False


def extract_socket_errors(ev: LogEvent) -> bool:
    """Classify socket and connection error patterns."""
    if _RE_SOCKET_ERROR.search(ev.message):
        ev.component = "system"
        ev.event_type = "system_socket_error"
        ev.severity = "warning"
        return True
    return False


def extract_bluetooth_lifecycle(ev: LogEvent) -> bool:
    """Classify Bluetooth connection lifecycle patterns."""
    if _RE_BLUETOOTH_LIFECYCLE.search(ev.message):
        ev.component = "bluetooth"
        ev.event_type = "bluetooth_lifecycle"
        return True
    return False


def extract_charger_detect(ev: LogEvent) -> bool:
    """Classify charger detection patterns."""
    m = _RE_CHARGER_DETECT.search(ev.message)
    if m:
        ev.component = "battery"
        ev.event_type = "battery_charger_detect"
        try:
            voltage = float(m.group(1))
            ev.battery = BatteryMetrics(voltage_mv=voltage * 1000)
        except ValueError:
            pass
        return True
    return False


def extract_headset_link_quality(ev: LogEvent) -> bool:
    """Classify SRX headset link quality reports."""
    if _RE_SRX_LINK_STATUS.search(ev.message):
        ev.component = "headset"
        ev.event_type = "headset_srx_link_quality"
        return True
    return False


def extract_sensor_processing(ev: LogEvent) -> bool:
    """Classify sensor data processing patterns."""
    if _RE_SENSOR_PROCESSING.search(ev.message):
        ev.component = "system"
        ev.event_type = "system_sensor_processing"
        return True
    return False


def extract_content_provider(ev: LogEvent) -> bool:
    """Classify content provider request patterns."""
    if _RE_CONTENT_PROVIDER.search(ev.message):
        ev.component = "system"
        ev.event_type = "system_content_request"
        return True
    return False


def extract_gws_prompts(ev: LogEvent) -> bool:
    """Classify GWS voice prompt text (##...##;pp), Delay records, and vocabulary config."""
    msg = ev.message

    if _RE_GWS_PROMPT_TEXT.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_prompt_text"
        return True

    if _RE_GWS_DELAY_RECORD.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_delay_record"
        return True

    if _RE_VOCAB_ADDITIONAL.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_vocab_config"
        return True

    return False


def extract_wifi_survey(ev: LogEvent) -> bool:
    """Classify WiFi SURVEY roaming events."""
    if _RE_SURVEY_ROAM.search(ev.message):
        ev.component = "wifi"
        ev.event_type = "wifi_roam_survey"
        return True
    return False


def extract_headset_extended(ev: LogEvent) -> bool:
    """Classify extended headset patterns: runtime info, mic boom, SRCOMM queries."""
    msg = ev.message

    if _RE_HEADSET_RUNTIME.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_runtime_info"
        return True

    if _RE_MIC_BOOM_FLIP.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_mic_boom"
        return True

    if _RE_SRCOMM_STATUS_QUERY.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_status_query"
        return True

    return False


def extract_dialog_extended(ev: LogEvent) -> bool:
    """Classify extended dialog/speech system patterns."""
    msg = ev.message

    if _RE_DIALOG_AUTO_OPERATOR.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_dialog_auto_operator"
        return True

    if _RE_INIT_FOR_RECOG.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_grammar_refresh"
        return True

    if _RE_MID_UTTERANCE_GRAMMAR.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_mid_utterance"
        return True

    if _RE_PMS_RECEIVE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_pms_transport"
        return True

    if _RE_INPROCESS_MODULE.search(msg):
        ev.component = "system"
        ev.event_type = "system_module_proxy"
        return True

    return False


def extract_remaining_system(ev: LogEvent) -> bool:
    """Catch remaining small-count system/scanner/speech patterns."""
    msg = ev.message

    if _RE_SCANNER_STATE_CHANGE.search(msg):
        ev.component = "scanner"
        ev.event_type = "scanner_state_change"
        return True

    if _RE_SCANNER_MISC.search(msg):
        ev.component = "scanner"
        ev.event_type = "scanner_misc"
        return True

    if _RE_BT_STACK_API.search(msg):
        ev.component = "bluetooth"
        ev.event_type = "bluetooth_stack_api"
        return True

    if _RE_EVENT_OPERATIONS.search(msg):
        ev.component = "system"
        ev.event_type = "system_event_operations"
        return True

    if _RE_GUIDEDWORK.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_guided_work"
        return True

    if _RE_INACTIVITY_POWER.search(msg):
        ev.component = "system"
        ev.event_type = "system_power_inhibitor"
        return True

    if _RE_RAM_FILESYSTEM.search(msg):
        ev.component = "system"
        ev.event_type = "system_ram_filesystem"
        return True

    if _RE_WORD_DISABLED.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_word_disabled"
        return True

    if _RE_GRAMMAR_ID.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_grammar_id"
        return True

    if _RE_RECOGNIZER_CALLBACK.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_callback"
        return True

    # Pass-3c broad catch-alls
    if _RE_EVDETCT_BATTERY.search(msg):
        ev.component = "battery"
        ev.event_type = "battery_level_detect"
        return True

    if _RE_HEADSET_MISC.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_misc"
        return True

    if _RE_SPEECH_MISC.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_misc"
        return True

    if _RE_SYSTEM_MISC.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    # Pass-3c: audio frontend
    if _RE_AUDIO_FRONTEND.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_frontend"
        return True

    # Pass-3c: remaining catch-all
    if _RE_REMAINING_CATCH_ALL.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    return False


def extract_final_long_tail(ev: LogEvent) -> bool:
    """Classify the remaining 0.99% long-tail patterns (Pass-4)."""
    msg = ev.message

    if _RE_TIPM_EXTENDED.search(msg):
        ev.component = "system"
        ev.event_type = "system_tipm_config"
        return True

    if _RE_VC_STATE.search(msg):
        ev.component = "system"
        ev.event_type = "system_vc_state"
        return True

    if _RE_BUTTON_KEYPRESS.search(msg):
        ev.component = "system"
        ev.event_type = "system_button_keypress"
        return True

    if _RE_AUDIO_PATH.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_path"
        return True

    if _RE_SYSTEM_LIFECYCLE.search(msg):
        ev.component = "system"
        ev.event_type = "system_lifecycle"
        return True

    if _RE_RECOGNIZER_EXTENDED.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_extended"
        return True

    if _RE_SRX_AUDIO.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_srx_audio"
        return True

    if _RE_AI_CHANGE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_ai_change"
        return True

    if _RE_VOICECONSOLE_STARTUP.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_voiceconsole_startup"
        return True

    if _RE_RSA_TELEMETRY.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_rsa_telemetry"
        return True

    if _RE_CONFIG_ITEM_DISCOVERY.search(msg):
        ev.component = "system"
        ev.event_type = "system_config_discovery"
        return True

    if _RE_EVENT_SENSOR_EXTENDED.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_event"
        return True

    if _RE_BLUETOOTH_EXTENDED.search(msg):
        ev.component = "bluetooth"
        ev.event_type = "bluetooth_extended"
        return True

    if _RE_SYSTEM_EVENTS_EXTENDED.search(msg):
        ev.component = "system"
        ev.event_type = "system_event_extended"
        return True

    # Pass-4b second wave
    if _RE_TIPM_SET.search(msg):
        ev.component = "system"
        ev.event_type = "system_tipm_config"
        return True

    if _RE_BEEP_EVENTS.search(msg):
        ev.component = "system"
        ev.event_type = "system_beep"
        return True

    if _RE_VOICE_ADAPT_TRAIN.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_voice_training"
        return True

    if _RE_PLATFORM_SERVICES.search(msg):
        ev.component = "system"
        ev.event_type = "system_platform_service"
        return True

    if _RE_DIALOG_NOTIFY.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_dialog_notify"
        return True

    if _RE_CHARGER_STATUS.search(msg):
        ev.component = "battery"
        ev.event_type = "battery_charger_status"
        return True

    if _RE_THREAD_PRIORITY.search(msg):
        ev.component = "system"
        ev.event_type = "system_thread_config"
        return True

    if _RE_SUPERVISOR_AUDIO.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_config"
        return True

    if _RE_BT_CONFIG.search(msg):
        ev.component = "bluetooth"
        ev.event_type = "bluetooth_config"
        return True

    if _RE_GUIDEDWORK_STARTUP.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_guided_work"
        return True

    if _RE_TIME_ZONE.search(msg):
        ev.component = "system"
        ev.event_type = "system_timezone"
        return True

    # Pass-4c third wave
    if _RE_CONFIG_ITEM_KV.search(msg):
        ev.component = "system"
        ev.event_type = "system_config_discovery"
        return True

    if _RE_ADD_SENSOR.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_registration"
        return True

    if _RE_TAI_CONNECT.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_tai_connect"
        return True

    if _RE_DST_METADATA.search(msg):
        ev.component = "system"
        ev.event_type = "system_timezone"
        return True

    if _RE_AUDIO_CAPTURE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_capture"
        return True

    if _RE_TIPM_DIR.search(msg):
        ev.component = "system"
        ev.event_type = "system_tipm_config"
        return True

    if _RE_THREAD_START.search(msg):
        ev.component = "system"
        ev.event_type = "system_thread_config"
        return True

    if _RE_OPER_LIFECYCLE.search(msg):
        ev.component = "system"
        ev.event_type = "system_operator_lifecycle"
        return True

    if _RE_SENSOR_REFRESH.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_event"
        return True

    # Pass-4d final sweep
    if _RE_SRCOMM_DISCONNECT.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_srcomm_lifecycle"
        return True

    if _RE_MAINTENANCE_MODE.search(msg):
        ev.component = "system"
        ev.event_type = "system_maintenance_mode"
        return True

    if _RE_GUIDEDWORK_MAIN.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_guided_work"
        return True

    # ── Pass-5: Perfection sweep ─────────────────────────────────────────────

    # ASR output (^^...) — largest remaining category (~24k events)
    if _RE_ASR_RESULT.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_asr_result"
        return True

    if _RE_THREAD_LIFECYCLE.search(msg):
        ev.component = "system"
        ev.event_type = "system_thread_lifecycle"
        return True

    if _RE_MODULE_INIT.search(msg):
        ev.component = "system"
        ev.event_type = "system_module_init"
        return True

    if _RE_SRCOMM_LIFECYCLE.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_srcomm_lifecycle"
        return True

    if _RE_SRX2_TELEMETRY.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_srx2_telemetry"
        return True

    if _RE_SERVICE_REGISTRY.search(msg):
        ev.component = "system"
        ev.event_type = "system_service_registry"
        return True

    if _RE_CONTROL_FUNCTION.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_control_function"
        return True

    if _RE_TTS_PROXY.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_tts_event"
        return True

    if _RE_EXECUTE_CMD.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_execute_command"
        return True

    if _RE_CONNECT_LIFECYCLE.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_connect_lifecycle"
        return True

    if _RE_SENSOR_CONFIG.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_config"
        return True

    if _RE_SENSOR_LISTENER_REG.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_registration"
        return True

    if _RE_HEADSET_HW.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_hardware_info"
        return True

    if _RE_AI_SWITCHING.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_ai_switch"
        return True

    if _RE_RECORDER_AUDIO.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_recorder"
        return True

    if _RE_VC_MAIN_THREAD.search(msg):
        ev.component = "system"
        ev.event_type = "system_vc_main_thread"
        return True

    if _RE_AP_MONITOR.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_ap_monitor"
        return True

    if _RE_CONFIG_SETUP.search(msg):
        ev.component = "system"
        ev.event_type = "system_config_setup"
        return True

    if _RE_VOICE_TRAINING.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_voice_training"
        return True

    if _RE_NOISE_SAMPLE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_noise_sample"
        return True

    if _RE_MINUS_BUTTON.search(msg):
        ev.component = "system"
        ev.event_type = "system_button_keypress"
        return True

    if _RE_SIDETONE.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_srx_audio"
        return True

    if _RE_TIPM_AUDIO_HEADSET.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_tipm_notification"
        return True

    if _RE_POWER_NOTIFY.search(msg):
        ev.component = "system"
        ev.event_type = "system_power_management"
        return True

    if _RE_MISC_SYSTEM.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    if _RE_VERB_LIFECYCLE.search(msg):
        ev.component = "system"
        ev.event_type = "system_lifecycle"
        return True

    if _RE_INIT_LIFECYCLE.search(msg):
        ev.component = "system"
        ev.event_type = "system_module_init"
        return True

    if _RE_COMM_ERROR.search(msg):
        ev.component = "system"
        ev.event_type = "system_comm_error"
        ev.severity = "warning"
        return True

    if _RE_RSA_UTS.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_rsa_telemetry"
        return True

    if _RE_VAD_REVISION.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_vad_revision"
        return True

    # ── Pass-5b: Second wave ─────────────────────────────────────────────────

    if _RE_LANG_TTS_PROXY.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_tts_proxy"
        return True

    if _RE_LOOKUP_SERVICE_EXTRA.search(msg):
        ev.component = "system"
        ev.event_type = "system_service_registry"
        return True

    if _RE_STARTUP_SEQ.search(msg):
        ev.component = "system"
        ev.event_type = "system_startup"
        return True

    if _RE_RTC_CLOCK.search(msg):
        ev.component = "system"
        ev.event_type = "system_timezone"
        return True

    if _RE_TSND_TEMPLATE.search(msg):
        ev.component = "system"
        ev.event_type = "system_template_send"
        return True

    if _RE_USERDATA.search(msg):
        ev.component = "system"
        ev.event_type = "system_userdata"
        return True

    if _RE_SYSAUDIO.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_audio_config"
        return True

    if _RE_NAMED_PIPE.search(msg):
        ev.component = "system"
        ev.event_type = "system_named_pipe"
        return True

    if _RE_TITAN_COMM.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_titan_comm"
        return True

    if _RE_SERIAL_USB.search(msg):
        ev.component = "system"
        ev.event_type = "system_serial_usb"
        return True

    if _RE_SCRIPTING_WEB.search(msg):
        ev.component = "system"
        ev.event_type = "system_scripting"
        return True

    if _RE_BLE_INIT.search(msg):
        ev.component = "bluetooth"
        ev.event_type = "bluetooth_ble_init"
        return True

    if _RE_MESSAGE_QUEUE.search(msg):
        ev.component = "system"
        ev.event_type = "system_message_queue"
        return True

    if _RE_SOCKSEND_EAP.search(msg):
        ev.component = "system"
        ev.event_type = "system_event_signal"
        return True

    if _RE_BATTERY_NEGATIVE.search(msg):
        ev.component = "battery"
        ev.event_type = "battery_properties"
        ev.severity = "warning"
        return True

    if _RE_ZMQ_MISC.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    if _RE_EXIT_DIALOG.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_dialog_exit"
        return True

    if _RE_ASR_ENGINE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_asr_engine"
        return True

    if _RE_SYSTEM_ASSERT.search(msg):
        ev.component = "system"
        ev.event_type = "system_config_setup"
        return True

    if _RE_BSD_COMM.search(msg):
        ev.component = "system"
        ev.event_type = "system_comm_lifecycle"
        return True

    if _RE_CAB_VERSION.search(msg):
        ev.component = "system"
        ev.event_type = "system_device_info"
        return True

    if _RE_REQUEST_TIME.search(msg):
        ev.component = "system"
        ev.event_type = "system_timezone"
        return True

    if _RE_VC_STARTUP.search(msg):
        ev.component = "system"
        ev.event_type = "system_vc_main_thread"
        return True

    if _RE_CREATING_OBJ.search(msg):
        ev.component = "system"
        ev.event_type = "system_startup"
        return True

    if _RE_STARTING_OBJ.search(msg):
        ev.component = "system"
        ev.event_type = "system_startup"
        return True

    if _RE_MISC_VERBS.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    if _RE_RECEIVED_ERR.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc"
        return True

    if _RE_SIGNAL_THREAD.search(msg):
        ev.component = "wifi"
        ev.event_type = "wifi_signal_thread"
        return True

    if _RE_RECOG_DELAY.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognizer_extended"
        return True

    if _RE_ATTEMPTING.search(msg):
        ev.component = "system"
        ev.event_type = "system_lifecycle"
        return True

    # --- Pass-5 Wave 3: final 403 events ---

    if _RE_MAINT_MODE.search(msg):
        ev.component = "system"
        ev.event_type = "system_maintenance_mode"
        return True

    if _RE_SENSOR_READ_THREAD.search(msg):
        ev.component = "system"
        ev.event_type = "system_sensor_thread"
        return True

    if _RE_HTTP_RESOURCE_MGR.search(msg):
        ev.component = "system"
        ev.event_type = "system_http_resource"
        return True

    if _RE_VSPEAK_SVC.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_vspeak_service"
        return True

    if _RE_FILE_SENT_VC.search(msg):
        ev.component = "system"
        ev.event_type = "system_file_transfer"
        return True

    if _RE_OPERATOR_ACTIONS.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_operator_action"
        return True

    if _RE_BT_NFC_PAIRING.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_bt_nfc_pairing"
        return True

    if _RE_TASK_PACKAGE.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_task_package"
        return True

    if _RE_TEMPLATE_HIB.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_template_hibernate"
        return True

    if _RE_MISC_DEVICE_OPS.search(msg):
        ev.component = "system"
        ev.event_type = "system_device_ops"
        return True

    if _RE_GRAMMAR_STOP.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_grammar_stop"
        return True

    if _RE_SIDETONE_EXT.search(msg):
        ev.component = "headset"
        ev.event_type = "headset_sidetone_extended"
        return True

    if _RE_GETNOISE.search(msg):
        ev.component = "speech"
        ev.event_type = "speech_noise_sample"
        return True

    if _RE_BLE_CALLBACK.search(msg):
        ev.component = "scanner"
        ev.event_type = "scanner_ble_callback"
        return True

    if _RE_ACTION_DIALOG.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_action_dialog"
        return True

    if _RE_VOC_IMG.search(msg):
        ev.component = "system"
        ev.event_type = "system_img_callback"
        return True

    if _RE_STACK_TRACE.search(msg):
        ev.component = "system"
        ev.event_type = "system_error_trace"
        ev.severity = "error"
        return True

    if _RE_STATE_MACHINE.search(msg):
        ev.component = "gws"
        ev.event_type = "gws_state_machine"
        return True

    if _RE_MISC_FINAL.search(msg):
        ev.component = "system"
        ev.event_type = "system_misc_event"
        return True

    return False


def classify_event(ev: LogEvent) -> None:
    """Classify and extract metrics from a LogEvent in-place."""
    # Already classified (e.g. messages_lost detected during parsing)
    if ev.event_type != "generic":
        return

    msg = ev.message

    # Try domain extractors first
    if extract_battery(ev):
        return
    if extract_wifi(ev):
        return

    # New: System resource extractors
    if extract_system_resources(ev):
        return

    if extract_system_diagnostics(ev):
        return

    # New: Operator / headset extractors
    if extract_operator(ev):
        return
    if extract_headset(ev):
        return

    # Messages lost
    if _RE_MESSAGES_LOST.search(msg):
        ev.component = "system"
        ev.event_type = "messages_lost"
        ev.severity = "warning"
        return

    # New: Structured GWS workflow events (before generic GWS catch-all)
    if extract_gws_workflow(ev):
        return

    # New: Voice recognized words (before generic speech catch-all)
    if extract_voice(ev):
        return

    if extract_speech_diagnostics(ev):
        return

    # Pass-3: Extended speech pipeline (EOS, NTOPP, prompts, etc.)
    if extract_speech_pipeline(ev):
        return

    # Pass-3: Scanner / BLE lifecycle (extended)
    if extract_scanner_lifecycle(ev):
        return

    # Pass-3: Dialog workflow (enter/exit/transition)
    if extract_dialog_workflow(ev):
        return

    # Pass-3: Battery negative runtime and compact format
    if extract_battery_extended(ev):
        return

    # Pass-3: Feature licensing
    if extract_licensing(ev):
        return

    # Pass-3: Power management
    if extract_power_management(ev):
        return

    # Pass-3: Radio / device info
    if extract_radio_device_info(ev):
        return

    # Pass-3: Socket / connection errors
    if extract_socket_errors(ev):
        return

    # Pass-3: Bluetooth lifecycle
    if extract_bluetooth_lifecycle(ev):
        return

    # Pass-3: Charger detection
    if extract_charger_detect(ev):
        return

    # Pass-3: Headset link quality
    if extract_headset_link_quality(ev):
        return

    # Pass-3: Sensor processing
    if extract_sensor_processing(ev):
        return

    # Pass-3: Content provider
    if extract_content_provider(ev):
        return

    # Pass-3b: GWS voice prompts and delay records
    if extract_gws_prompts(ev):
        return

    # Pass-3b: WiFi SURVEY roaming
    if extract_wifi_survey(ev):
        return

    # Pass-3b: Extended headset (runtime, mic boom, SRCOMM)
    if extract_headset_extended(ev):
        return

    # Pass-3b: Extended dialog/speech system
    if extract_dialog_extended(ev):
        return

    # Pass-3b: Remaining small-count system/scanner/speech patterns
    if extract_remaining_system(ev):
        return

    # Pass-4: Final long-tail patterns (remaining 0.99%)
    if extract_final_long_tail(ev):
        return

    # GWS state machine (generic catch-all)
    if _RE_GWS.match(msg):
        ev.component = "gws"
        ev.event_type = "gws_state"
        return

    # Platform / kernel
    if _RE_PLATFORM.match(msg):
        ev.component = "platform"
        ev.event_type = "platform_log"
        # Re-check for battery/wifi inside platform messages
        if extract_battery(ev) or extract_wifi(ev):
            return
        return

    # Speech / recognition (generic catch-all)
    if _RE_SPCHDET.match(msg) or _RE_RECOG.match(msg):
        ev.component = "speech"
        ev.event_type = "speech_recognition"
        return

    # Fallback
    ev.component = "other"
    ev.event_type = "generic"
