#!/usr/bin/env python3
"""Remove targeted imports from Python or JS/TS files.

Examples:
    python tools/remove_selected_imports.py app/main.py Optional JSONResponse
    python tools/remove_selected_imports.py src/App.tsx useMemo useCallback
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

PY_FROM_RE = re.compile(r"^(?P<indent>\s*)from\s+(?P<module>[\w.]+)\s+import\s+(?P<names>.+?)\s*$")
PY_IMPORT_RE = re.compile(r"^(?P<indent>\s*)import\s+(?P<names>.+?)\s*$")
JS_NAMED_RE = re.compile(
    r"^(?P<indent>\s*)import\s*\{(?P<names>[^}]+)\}\s*from\s*(?P<rest>.+?);?\s*$"
)
JS_DEFAULT_RE = re.compile(
    r"^(?P<indent>\s*)import\s+(?P<name>[A-Za-z_$][\w$]*)\s+from\s*(?P<rest>.+?);?\s*$"
)


def normalize_symbol(token: str) -> str:
    token = token.strip()
    if " as " in token:
        token = token.split(" as ", 1)[-1].strip()
    return token.strip()


def filter_python_from_import(line: str, symbols: set[str]) -> str | None:
    match = PY_FROM_RE.match(line)
    if not match:
        return line
    names = [part.strip() for part in match.group("names").split(",")]
    kept = [part for part in names if normalize_symbol(part) not in symbols]
    if not kept:
        return None
    return f"{match.group('indent')}from {match.group('module')} import {', '.join(kept)}"


def filter_python_import(line: str, symbols: set[str]) -> str | None:
    match = PY_IMPORT_RE.match(line)
    if not match:
        return line
    names = [part.strip() for part in match.group("names").split(",")]
    kept = [part for part in names if normalize_symbol(part.split(".", 1)[0]) not in symbols]
    if not kept:
        return None
    return f"{match.group('indent')}import {', '.join(kept)}"


def filter_js_named_import(line: str, symbols: set[str]) -> str | None:
    match = JS_NAMED_RE.match(line)
    if not match:
        return line
    names = [part.strip() for part in match.group("names").split(",")]
    kept = [part for part in names if normalize_symbol(part) not in symbols]
    if not kept:
        return None
    return f"{match.group('indent')}import {{ {', '.join(kept)} }} from {match.group('rest')};"


def filter_js_default_import(line: str, symbols: set[str]) -> str | None:
    match = JS_DEFAULT_RE.match(line)
    if not match:
        return line
    if normalize_symbol(match.group("name")) in symbols:
        return None
    return f"{match.group('indent')}import {match.group('name')} from {match.group('rest')};"


def transform_lines(lines: list[str], symbols: set[str], suffix: str) -> list[str]:
    output: list[str] = []
    for raw_line in lines:
        line = raw_line.rstrip("\n")
        new_line: str | None = line
        if suffix in {".py"}:
            new_line = filter_python_from_import(line, symbols)
            if new_line is not None:
                new_line = filter_python_import(new_line, symbols)
        elif suffix in {".js", ".jsx", ".ts", ".tsx"}:
            new_line = filter_js_named_import(line, symbols)
            if new_line is not None:
                new_line = filter_js_default_import(new_line, symbols)
        if new_line is not None:
            output.append(new_line + "\n")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Remove selected import symbols from a source file.")
    parser.add_argument("file", help="Path to the source file")
    parser.add_argument("symbols", nargs="+", help="Imported symbols or modules to remove")
    parser.add_argument("--dry-run", action="store_true", help="Print result instead of writing file")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        raise SystemExit(f"File not found: {path}")

    symbols = {symbol.strip() for symbol in args.symbols if symbol.strip()}
    original = path.read_text(encoding="utf-8").splitlines(keepends=True)
    updated = transform_lines(original, symbols, path.suffix)

    if args.dry_run:
        print("".join(updated), end="")
        return 0

    path.write_text("".join(updated), encoding="utf-8")
    print(f"Updated {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
