# Honeywell Log Parser V2 - AI Handoff Master Prompt

Use this file as the first prompt/context document for a new AI working in a fresh repository.

## Objective
Build a clean V2 of the Honeywell log parser with a focused UI and reuse only the proven parsing and anomaly logic from the previous project.

## Deliverable
A deployable log analysis application for the GTS Hackathon that:
- parses A700x device logs at large scale
- shows battery drain and temperature over time
- shows Wi-Fi signal and roaming issues over time
- highlights offending values clearly
- exports HTML/PDF/CSV reports
- is easy to use and easy to extend

## Source Material Included In This Starter Kit

### Domain and judging documents
- docs/GTS Hackathon 2026 Requirements.md
- docs/A700x_Datalog_Parser_Reference.md
- docs/Vocollect_Talkman_A500_Comprehensive_Guide.md
- docs/IMPLEMENTATION_PLAN.md

### Proven Python modules to reuse as-is
- core/app/parser/__init__.py
- core/app/parser/streaming.py
- core/app/extractors/__init__.py
- core/app/anomaly/__init__.py
- core/app/db/__init__.py
- core/app/exports/__init__.py
- core/app/config.py

### Infra/reference files
- infra/requirements.txt
- infra/requirements-dev.txt
- infra/pyproject.toml
- infra/Dockerfile
- infra/railway.json

### Sample logs
- logs/Log_7623205329_2024-02-28_14-30-53-541.zip
- logs/Log_7623205333_2024-02-28_14-30-31-580.zip

### Utilities
- tools/remove_selected_imports.py

## Hard Constraints
- Do not rewrite the parser, extractor, anomaly, db, exports, or config modules unless there is a verified bug.
- Treat those modules as the trusted data-processing core.
- Build the new application around them.
- Keep the UI focused on hackathon judging criteria rather than old exploratory features.

## Judging Criteria To Optimize For
1. Easy to use
2. Scalable and configurable
3. Offending values clearly highlighted
4. Additional reporting capabilities

## Recommended Primary Architecture
Use Python + FastAPI for the new app, because the included proven logic is already Python and production-ready.

### Build from scratch
- app/main.py
- app/templates/base.html
- app/templates/index.html
- app/templates/session.html
- app/templates/events.html
- app/templates/anomalies.html
- app/static/css/style.css
- app/static/js/charts.js
- tests/test_smoke.py
- README.md

### Reuse from starter kit
- parser models and streaming parser
- event classification logic
- anomaly engine
- SQLite persistence layer
- export helpers
- configuration thresholds

## Alternative Architecture Included As Reference
There is an alternative frontend-only React/Web Worker proposal in docs/ALTERNATIVE_BROWSER_ARCHITECTURE.md.
Use it only as a design reference unless you intentionally decide to port the Python parser logic into JavaScript.
That path is higher risk because it abandons the already-proven Python extraction/anomaly modules.

## Decision Guidance
Choose one of these explicitly:

### Option A - Recommended
- FastAPI backend
- Jinja templates
- Chart.js frontend
- SQLite persistence
- reuse Python core directly

### Option B - Higher Risk
- React SPA + Web Worker + browser-only parsing
- requires porting parser logic or re-implementing it
- only use if backendless deployment is a strict requirement

## Pages Required In V2
1. Home/upload page
2. Session analysis page
3. Event explorer page
4. Anomaly page
5. Export routes

## Session Page Must Include
- device metadata card
- KPI cards for events, anomalies, battery drain, temperature range, signal range, roams
- battery chart with percent and temperature
- Wi-Fi chart with signal and roaming markers
- anomaly table with highlighted values
- export buttons

## Offending Value Highlighting Rules
- battery temp >= 45C: red
- battery <= 15%: red
- Wi-Fi signal <= 20%: yellow
- CPU >= 80%: yellow
- any critical anomaly row: red row treatment
- any warning anomaly row: amber row treatment

## Build Order
1. Set up fresh repo structure
2. Copy reused Python core into the new repo
3. Create the FastAPI entrypoint and routing skeleton
4. Implement upload + ingest flow
5. Implement session summary calculations and charts
6. Add exports
7. Add tests
8. Add docs

## What To Ignore From The Old Project
Do not reintroduce these older ideas unless explicitly needed:
- fleet comparison views
- global search across all sessions
- coverage admin pages
- stale recommendation-heavy cards
- overgrown CSS and monolithic route handlers

## Import Cleanup Utility
If the new AI or you remove routes/components and imports become stale, use:

```bash
python tools/remove_selected_imports.py path/to/file.py SymbolOne SymbolTwo
python tools/remove_selected_imports.py path/to/file.ts useMemo useCallback
```

It supports basic Python and JS/TS import cleanup for targeted symbols.

## Final Instruction To The New AI
Build a new, minimal, high-confidence application around the included proven parser core. Favor clarity, correctness, and delivery speed over feature sprawl.
