# Honeywell Log Parser V2 - FastAPI Rebuild Specification

## Goal
Rebuild the application from scratch while preserving the proven Python parsing core.

## Keep And Reuse
- core/app/parser/__init__.py
- core/app/parser/streaming.py
- core/app/extractors/__init__.py
- core/app/anomaly/__init__.py
- core/app/db/__init__.py
- core/app/exports/__init__.py
- core/app/config.py

## Build New
- app/main.py
- app/templates/*
- app/static/css/style.css
- app/static/js/charts.js
- tests/test_smoke.py
- README.md

## Required Routes
- GET /
- POST /upload
- POST /session/{id}/delete
- GET /session/{id}
- GET /session/{id}/events
- GET /session/{id}/anomalies
- GET /session/{id}/export/events.csv
- GET /session/{id}/export/events.json
- GET /session/{id}/export/anomalies.csv
- GET /session/{id}/export/report.html
- GET /session/{id}/export/report.pdf

## Required Charts
- Battery percent over time
- Battery temperature over time
- Energy consumption over time
- Wi-Fi signal strength over time
- Roaming markers on Wi-Fi chart

## Required UI Surfaces
- upload page
- session summary dashboard
- anomaly table
- event explorer
- export controls

## Rules
- Do not replace the parser core unless a verified defect is found.
- Keep the code modular.
- Keep the UI simple.
- Highlight offending values clearly.
- Support large logs without loading the whole file into memory.

## Core Ingest Flow
1. Parse header with parse_file_with_meta()
2. Insert session metadata
3. Stream events
4. classify_event() on each event
5. AnomalyEngine.process() on each event
6. Batch-insert events/anomalies
7. Build summary metrics
8. Render dashboards and exports from stored data

## Metrics That Must Be Prominent
- battery drain
- battery temperature range
- battery critical periods
- Wi-Fi signal quality
- roaming count
- connection failures
- top anomaly types

## Judging Alignment
- easy upload and review flow
- scalable config-driven thresholds
- visible highlighted bad values
- exportable reports
