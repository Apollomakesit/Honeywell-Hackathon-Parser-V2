# Linux Device Log Parser Plan

## Decision Summary

- The Linux log data is valid, large, and rich enough to drive the new parser design.
- The example parser was useful as a temporary reference during scaffolding, but it is no longer required in the repository.
- Decision: remove the example parser folder and keep the new app self-contained.

## Data Analysis

### Input Files

- [Linux_device_logs/extracted/7623205329/Log_7623205329_2024-02-28_14-30-53-541.txt](Linux_device_logs/extracted/7623205329/Log_7623205329_2024-02-28_14-30-53-541.txt)
- [Linux_device_logs/extracted/7623205333/Log_7623205333_2024-02-28_14-30-31-580.txt](Linux_device_logs/extracted/7623205333/Log_7623205333_2024-02-28_14-30-31-580.txt)

### Scale

- First log: 1,631,052 lines
- Second log: 1,596,142 lines
- Total: 3,227,194 lines

### Shared Header Structure

Each file starts with a consistent header block:

- Log Start Time
- Log Stop Time
- Log Type
- Terminal Name
- Terminal Serial Number
- Firmware Version
- IP Address

This gives us device/session metadata that should be captured once per file and attached to downstream parsed events.

### Observed Event Format

Most events use this structure:

```text
(2/28/24 2:31:24 PM CET) 14:14:50.300 - 43775256: message
```

The parser should treat this as:

- Server timestamp
- Device time
- Device tick / event id
- Raw event payload

### Observed Log Families

The sample files contain at least these event families:

1. Battery telemetry
2. Wi-Fi survey and roaming activity
3. Platform and kernel logs
4. GWS state-machine workflow logs
5. Speech/recognition logs
6. Scanner and BLE logs
7. Peripheral and headset state logs
8. Message-loss markers

### Battery Coverage In Samples

Battery-related matches observed:

- 7623205329: 9,238 lines
- 7623205333: 9,184 lines

Observed battery fields include:

- `Battery runtime remaining`
- `Battery percent remaining`
- `BATMON:` voltage, current, temperature
- `EnergyConsumption`
- `Temperature`

This is enough to support battery drain, temperature-over-time, and energy-consumption reporting.

### Wi-Fi Coverage In Samples

Wi-Fi-related matches observed:

- 7623205329: 7,477 lines
- 7623205333: 6,617 lines

Observed Wi-Fi fields include:

- `SURVEY: Access Point`
- `SURVEY: Signal Strength`
- `ROAMED`
- `Connected to bssid`
- `Beacon RSSI_LOW` and related kernel events
- `sched_scan` lifecycle events

This is enough to support signal-strength timelines, roaming analysis, connection health, and anomaly detection around weak signal and unstable handoffs.

### Parsing Risks Confirmed By The Data

1. Multiline events are real.
2. Some logical events span many sequential lines, especially `GWS:` records and JSON-like blocks.
3. `WARNING! Messages lost!` appears as a standalone line and means data gaps must be surfaced explicitly.
4. Log payloads mix structured, semi-structured, and freeform text.
5. The files are too large for naive all-in-memory parsing.

## Recommended Normalized Schema

The parser should normalize each event into a shared event model with these fields:

- `source_file`
- `terminal_name`
- `terminal_serial_number`
- `firmware_version`
- `ip_address`
- `server_timestamp`
- `device_time`
- `device_tick`
- `component`
- `event_type`
- `severity`
- `message`
- `event_group_id`
- `line_start`
- `line_end`
- `battery_metrics` object
- `wifi_metrics` object
- `tags`
- `anomalies`

This will let us present one unified UI while still keeping domain-specific metric extraction.

## Parser Strategy

### Phase 1: Ingestion And Profiling

1. Stream the log files line by line.
2. Parse and store the header metadata once per file.
3. Detect event starts using the timestamp prefix.
4. Group multiline records until the next event start.
5. Preserve original line ranges for traceability.

### Phase 2: Event Classification

Build dedicated extractors for:

1. Battery summary lines
2. `BATMON` telemetry lines
3. Wi-Fi survey lines
4. Roaming and association lines
5. Platform/kernel wireless lines
6. GWS state transitions
7. Message-loss warnings

### Phase 3: Anomaly Detection

Implement deterministic rules first:

1. Battery drain spikes
2. Temperature spikes
3. Rapid battery percent drop
4. Weak-signal periods over threshold
5. Frequent AP roaming in short windows
6. Connection failures and reconnect loops
7. Message-loss segments
8. Orphaned scan events or malformed event sequences

Then add heuristic summaries:

1. Most unstable Wi-Fi intervals
2. Worst battery-drain intervals
3. Highest anomaly-density windows

### Phase 4: Reporting And UI

The first usable UI should provide:

1. File/session summary cards
2. Battery timeline charts
3. Wi-Fi signal and roaming timeline charts
4. Search and filtering by event type, component, and anomaly
5. Drill-down to raw event text with offending values highlighted
6. Export to JSON, CSV, and HTML report

## Build Plan For The New Parser

### Step 1: Scaffold The New App From Scratch

Create a new project with:

1. Python backend
2. Parser package
3. Report/UI layer
4. Railway deployment files
5. Config and environment handling

### Step 2: Build The Core Parser

1. Header parser
2. Streaming event assembler
3. Event classifier registry
4. Battery extractor
5. Wi-Fi extractor
6. Generic fallback extractor

### Step 3: Build Storage And Outputs

1. Write normalized events to SQLite or structured JSON cache
2. Aggregate battery and Wi-Fi metrics
3. Store anomaly results with raw-source traceability

### Step 4: Build The Web Interface

1. Upload/select parsed sessions
2. Dashboard overview
3. Battery insights
4. Wi-Fi insights
5. Event explorer
6. Export report page

### Step 5: Prepare Hackathon Deliverables

1. Functional parser
2. Self-explanatory web report
3. Exportable HTML/PDF summary
4. Screenshots and architecture visuals for the concept presentation

## Immediate Next Actions

1. Scaffold the new Railway-ready project from scratch in a dedicated app folder.
2. Implement the streaming parser and normalized schema first.
3. Keep deployment, config, and UI concerns self-contained in this repository.
