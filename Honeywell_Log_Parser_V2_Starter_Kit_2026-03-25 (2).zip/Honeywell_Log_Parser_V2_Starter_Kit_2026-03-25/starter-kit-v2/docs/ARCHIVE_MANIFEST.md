# Starter Kit Manifest

## Included
- docs/AI_HANDOFF_MASTER_PROMPT.md
- docs/REBUILD_SPEC_FASTAPI.md
- docs/ALTERNATIVE_BROWSER_ARCHITECTURE.md
- docs/GTS Hackathon 2026 Requirements.md
- docs/A700x_Datalog_Parser_Reference.md
- docs/Vocollect_Talkman_A500_Comprehensive_Guide.md
- docs/IMPLEMENTATION_PLAN.md
- core/app/config.py
- core/app/parser/__init__.py
- core/app/parser/streaming.py
- core/app/extractors/__init__.py
- core/app/anomaly/__init__.py
- core/app/db/__init__.py
- core/app/exports/__init__.py
- infra/requirements.txt
- infra/requirements-dev.txt
- infra/pyproject.toml
- infra/Dockerfile
- infra/railway.json
- logs/Log_7623205329_2024-02-28_14-30-53-541.zip
- logs/Log_7623205333_2024-02-28_14-30-31-580.zip
- tools/remove_selected_imports.py

## Excluded On Purpose
- old monolithic UI templates
- old app/main.py
- old static CSS/JS
- fleet/global-search/admin surfaces
- current project git metadata
- runtime database and upload artifacts
