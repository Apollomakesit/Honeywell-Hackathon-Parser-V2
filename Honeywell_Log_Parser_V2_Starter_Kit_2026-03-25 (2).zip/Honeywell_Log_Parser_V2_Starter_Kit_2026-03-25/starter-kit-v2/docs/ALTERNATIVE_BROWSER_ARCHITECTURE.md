# Alternative Browser-Only Architecture Reference

This file captures the alternative rebuild direction proposed externally.
It is included as reference, not as the primary recommendation.

## Proposed Stack
- single-page React app
- Web Workers for parsing
- no backend
- drag-and-drop upload in browser
- PDF and CSV export from browser

## Why It Is Included
- useful for UI decomposition
- useful for worker/search-index design ideas
- useful if you later choose a backendless deployment model

## Why It Is Not The Primary Recommendation
- the proven parser/anomaly engine in this starter kit is Python
- browser-only architecture requires porting or re-implementing core parsing logic
- that increases risk close to the deadline

## Useful Ideas To Borrow
- worker-based background parsing
- explicit search index stage
- component-level UI decomposition
- search families and custom family configuration
- event viewer with highlight support

## Recommended Use
Borrow the structural ideas from this architecture while still building the new V2 around the included Python core.
